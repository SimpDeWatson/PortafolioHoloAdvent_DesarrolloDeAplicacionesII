package pe.edu.sistema.model;

import java.io.Serializable;

/**
 * Modelo de dominio Producto.
 * Representa un producto dentro del Sistema Web de Gestion de Productos.
 */
public class Producto implements Serializable {

    private String codigo;
    private String nombre;
    private String categoria;
    private double precio;
    private int stock;
    private String estado; // Disponible, Agotado, Descontinuado
    private byte[] imagen;     // imagen del producto (en memoria, opcional)
    private String imagenTipo; // tipo MIME: image/png, image/jpeg, ...

    public Producto() {
    }

    public Producto(String codigo, String nombre, String categoria, double precio, int stock, String estado) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.categoria = categoria;
        this.precio = precio;
        this.stock = stock;
        this.estado = estado;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    /**
     * Calcula el valor total en inventario de este producto (precio * stock).
     */
    public double getValorInventario() {
        return precio * stock;
    }

    @Override
    public String toString() {
        return "Producto{" +
                "codigo='" + codigo + '\'' +
                ", nombre='" + nombre + '\'' +
                ", categoria='" + categoria + '\'' +
                ", precio=" + precio +
                ", stock=" + stock +
                ", estado='" + estado + '\'' +
                '}';
    }

    public byte[] getImagen() {
        return imagen;
    }

    public void setImagen(byte[] imagen) {
        this.imagen = imagen;
    }

    public String getImagenTipo() {
        return imagenTipo;
    }

    public void setImagenTipo(String imagenTipo) {
        this.imagenTipo = imagenTipo;
    }

    /** Indica si el producto tiene una imagen cargada (usado por las vistas JSP). */
    public boolean isTieneImagen() {
        return imagen != null && imagen.length > 0;
    }
}
