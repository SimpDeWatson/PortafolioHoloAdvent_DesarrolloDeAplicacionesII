package pe.edu.sistema.controller;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

/**
 * Filtro de autenticación. Redirige a login.jsp si el usuario no ha iniciado sesión.
 * Excluye: login, recursos estáticos (css, js, img) y la página de sesión cerrada.
 */
@WebFilter("/*")
public class AuthFilter implements Filter {

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) res;

        String path = request.getRequestURI().substring(request.getContextPath().length());

        // Recursos públicos (no requieren login)
        boolean esPublico =
                path.equals("/login") ||
                path.equals("/login.jsp") ||
                path.equals("/cerrarSesion") ||
                path.equals("/sesionCerrada.jsp") ||
                path.startsWith("/css/") ||
                path.startsWith("/js/") ||
                path.startsWith("/img/") ||
                path.startsWith("/imagenes/") ||
                path.endsWith(".svg") ||
                path.endsWith(".css") ||
                path.endsWith(".js");

        if (esPublico) {
            chain.doFilter(req, res);
            return;
        }

        HttpSession session = request.getSession(false);
        boolean logueado = (session != null && session.getAttribute("usuarioLogueado") != null);

        if (logueado) {
            chain.doFilter(req, res);
        } else {
            response.sendRedirect(request.getContextPath() + "/login");
        }
    }
}
