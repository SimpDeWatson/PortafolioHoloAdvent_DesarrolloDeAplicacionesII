package pe.edu.sistema.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

/**
 * Controlador de inicio de sesión.
 * Credenciales válidas: usuario = Adrian | contraseña = hololive2026
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    private static final String USUARIO_VALIDO = "Adrian";
    private static final String CLAVE_VALIDA = "hololive2026";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session != null && session.getAttribute("usuarioLogueado") != null) {
            response.sendRedirect(request.getContextPath() + "/index.jsp");
            return;
        }
        request.getRequestDispatcher("/login.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String usuario = request.getParameter("usuario");
        String clave = request.getParameter("clave");

        if (USUARIO_VALIDO.equals(usuario) && CLAVE_VALIDA.equals(clave)) {
            HttpSession session = request.getSession(true);
            session.setAttribute("usuarioLogueado", USUARIO_VALIDO);
            // Actualizar también el atributo de aplicación para que las vistas lo muestren
            getServletContext().setAttribute("usuarioConectado", USUARIO_VALIDO);
            response.sendRedirect(request.getContextPath() + "/index.jsp");
        } else {
            request.setAttribute("error", "Usuario o contraseña incorrectos. Intenta de nuevo.");
            request.getRequestDispatcher("/login.jsp").forward(request, response);
        }
    }
}
