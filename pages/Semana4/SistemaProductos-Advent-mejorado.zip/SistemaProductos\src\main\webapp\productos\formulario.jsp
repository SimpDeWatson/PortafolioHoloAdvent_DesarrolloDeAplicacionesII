<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="titulo" value="${modo == 'editar' ? 'Editar producto' : 'Registrar producto'}" />
<c:set var="activo" value="${modo == 'editar' ? 'listar' : 'nuevo'}" />
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>${titulo} - ${nombreCorto}</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/estilos.css">
    <link rel="icon" type="image/svg+xml" href="${pageContext.request.contextPath}/img/favicon.svg">
    <script src="${pageContext.request.contextPath}/js/validaciones.js" defer></script>
</head>
<body class="pg-formulario">
<div class="app">
<%@ include file="/includes/menu.jsp" %>
<div class="main">
<%@ include file="/includes/header.jsp" %>
<main class="page">

    <section class="panel form">
        <div class="panel-head">
            <h2>${modo == 'editar' ? 'Datos del producto' : 'Nuevo producto'}</h2>
        </div>
        <div class="panel-body">

            <c:if test="${not empty errores}">
                <div class="alert alert-error">No se pudo guardar. Corrija los campos marcados en rojo.<c:if test="${avisoImagen}"> Vuelva a seleccionar la imagen.</c:if></div>
            </c:if>

            <form method="post" enctype="multipart/form-data" action="${pageContext.request.contextPath}/productos" onsubmit="return validarFormularioProducto();" novalidate>
                <input type="hidden" name="accion" value="${modo == 'editar' ? 'actualizar' : 'guardar'}">

                <div class="form-layout">
                <div class="grid">
                    <div class="sec">Información general</div>
                    <div class="field">
                        <label for="codigo">Código</label>
                        <input type="text" id="codigo" name="codigo" class="${not empty errores.codigo ? 'invalid' : ''}" value="<c:out value='${producto.codigo}'/>" placeholder="P007" maxlength="20" ${modo == 'editar' ? 'readonly' : ''}>
                        <span class="err" id="err-codigo"><c:out value="${errores.codigo}"/></span>
                    </div>
                    <div class="field">
                        <label for="nombre">Nombre</label>
                        <input type="text" id="nombre" name="nombre" class="${not empty errores.nombre ? 'invalid' : ''}" value="<c:out value='${producto.nombre}'/>" maxlength="80">
                        <span class="err" id="err-nombre"><c:out value="${errores.nombre}"/></span>
                    </div>
                    <div class="field">
                        <label for="categoria">Categoría</label>
                        <select id="categoria" name="categoria" class="${not empty errores.categoria ? 'invalid' : ''}">
                            <option value="">Seleccione</option>
                            <c:forEach var="cat" items="${categorias}">
                                <option value="${cat}" ${producto.categoria == cat ? 'selected' : ''}>${cat}</option>
                            </c:forEach>
                        </select>
                        <span class="err" id="err-categoria"><c:out value="${errores.categoria}"/></span>
                    </div>
                    <div class="sec">Precio e inventario</div>
                    <div class="field">
                        <label for="precio">Precio</label>
                        <div class="prefix"><span>S/</span>
                            <input type="number" step="0.01" min="0.01" id="precio" name="precio" class="${not empty errores.precio ? 'invalid' : ''}"
                                   value="${not empty precioTexto ? precioTexto : (producto.precio > 0 ? producto.precio : '')}">
                        </div>
                        <span class="err" id="err-precio"><c:out value="${errores.precio}"/></span>
                    </div>
                    <div class="field">
                        <label for="stock">Stock</label>
                        <input type="number" step="1" min="0" id="stock" name="stock" class="${not empty errores.stock ? 'invalid' : ''}"
                               value="${not empty stockTexto ? stockTexto : (modo == 'editar' ? producto.stock : '')}">
                        <span class="err" id="err-stock"><c:out value="${errores.stock}"/></span>
                    </div>

                    <div class="field">
                        <label for="estado">Estado</label>
                        <select id="estado" name="estado" class="${not empty errores.estado ? 'invalid' : ''}">
                            <option value="">Seleccione</option>
                            <c:forEach var="est" items="${estados}">
                                <option value="${est}" ${producto.estado == est ? 'selected' : ''}>${est}</option>
                            </c:forEach>
                        </select>
                        <span class="err" id="err-estado"><c:out value="${errores.estado}"/></span>
                    </div>
                </div>

                <aside class="side-photo">
                    <h3>Fotografía del producto <span class="muted">(opcional)</span></h3>
                    <div>
                        
                        <div class="upload">
                            <c:choose>
                                <c:when test="${producto.tieneImagen}">
                                    <c:url var="urlActual" value="/imagen"><c:param name="codigo" value="${producto.codigo}"/></c:url>
                                    <img id="vistaPrevia" class="preview" src="${urlActual}" alt="Vista previa" data-original="${urlActual}">
                                </c:when>
                                <c:otherwise>
                                    <img id="vistaPrevia" class="preview" src="${pageContext.request.contextPath}/img/sin-imagen.svg" alt="Vista previa" data-original="${pageContext.request.contextPath}/img/sin-imagen.svg">
                                </c:otherwise>
                            </c:choose>
                            <div>
                                <input type="file" id="imagen" name="imagen" accept="image/png,image/jpeg,image/gif,image/webp" class="${not empty errores.imagen ? 'invalid' : ''}">
                                <small class="hint">PNG, JPG, GIF o WEBP. Máximo 2 MB.${modo == 'editar' ? ' Si no elige una nueva, se conserva la actual.' : ''}</small>
                                <span class="err" id="err-imagen"><c:out value="${errores.imagen}"/></span>
                            </div>
                        </div>
                    </div>
                </aside>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">${modo == 'editar' ? 'Guardar cambios' : 'Registrar producto'}</button>
                    <a class="btn" href="${pageContext.request.contextPath}/productos?accion=listar">Cancelar</a>
                </div>
            </form>
        </div>
    </section>

</main>
<%@ include file="/includes/footer.jsp" %>
</div>
</div>
</body>
</html>
