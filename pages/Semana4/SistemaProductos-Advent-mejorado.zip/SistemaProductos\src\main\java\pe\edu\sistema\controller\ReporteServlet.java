package pe.edu.sistema.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import pe.edu.sistema.service.ProductoService;

import java.io.IOException;

/**
 * Controlador (Servlet) del modulo de Reportes:
 *  - Productos disponibles (stock > 0)
 *  - Resumen de productos (totales, valor de inventario, stock total)
 */
@WebServlet("/reportes")
public class ReporteServlet extends HttpServlet {

    private final ProductoService service = ProductoService.getInstancia();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String accion = request.getParameter("accion");
        if (accion == null) {
            accion = "resumen";
        }

        if ("disponibles".equals(accion)) {
            request.setAttribute("productos", service.listarDisponibles());
            forward(request, response, "/reportes/disponibles.jsp");
        } else {
            request.setAttribute("totalProductos", service.contarTotalProductos());
            request.setAttribute("totalDisponibles", service.contarDisponibles());
            request.setAttribute("totalAgotados", service.contarAgotados());
            request.setAttribute("valorInventario", service.calcularValorTotalInventario());
            request.setAttribute("stockTotal", service.calcularStockTotal());
            // Cantidad de productos por categoria (para el grafico de barras)
            java.util.Map<String, Integer> porCategoria = new java.util.LinkedHashMap<>();
            for (pe.edu.sistema.model.Producto p : service.listarTodos()) {
                porCategoria.merge(p.getCategoria(), 1, Integer::sum);
            }
            request.setAttribute("porCategoria", porCategoria);
            forward(request, response, "/reportes/resumen.jsp");
        }
    }

    private void forward(HttpServletRequest request, HttpServletResponse response, String ruta)
            throws ServletException, IOException {
        RequestDispatcher rd = request.getRequestDispatcher(ruta);
        rd.forward(request, response);
    }
}
