<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="titulo" value="Información" />
<c:set var="activo" value="info" />
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Información - ${nombreCorto}</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/estilos.css">
    <link rel="icon" type="image/svg+xml" href="${pageContext.request.contextPath}/img/favicon.svg">
    <script src="${pageContext.request.contextPath}/js/validaciones.js" defer></script>
</head>
<body class="pg-info">
<div class="app">
<%@ include file="/includes/menu.jsp" %>
<div class="main">
<%@ include file="/includes/header.jsp" %>
<main class="page">

    <div class="about">
        <section class="panel">
            <div class="about-hero">
                <h2>${nombreSistema}</h2>
                <p>${descripcionSistema}</p>
            </div>
            <div class="tech">
                <span>Java 17</span><span>JSP</span><span>Servlets</span><span>Maven</span>
                <span>Apache Tomcat 11</span><span>MVC</span><span>CSS3</span><span>JavaScript</span>
            </div>
            <dl class="info" style="border-top:1px solid var(--line)">
                <dt>Proyecto</dt><dd>${nombreSistema}</dd>
                <dt>Versión</dt><dd>1.0.0</dd>
                <dt>Arquitectura</dt><dd>Modelo, Vista, Controlador (MVC)</dd>
                <dt>Tecnologías</dt><dd>Java 17, JSP, Servlets, Maven, CSS3, JavaScript</dd>
                <dt>Servidor</dt><dd>Apache Tomcat 11</dd>
                <dt>Almacenamiento</dt><dd>Colección ArrayList en memoria, sin base de datos</dd>
            </dl>
        </section>

        <section class="panel">
            <div class="panel-head"><h2>Datos académicos</h2></div>
            <dl class="info" style="grid-template-columns:120px 1fr">
                <dt>Curso</dt><dd>Desarrollo de Aplicaciones I, Universidad Peruana Los Andes</dd>
                <dt>Docente</dt><dd>Mg. Ing. Raúl Fernández Bejarano</dd>
                <dt>Autor</dt><dd>${usuarioConectado}</dd>
            </dl>
        </section>
    </div>

</main>
<%@ include file="/includes/footer.jsp" %>
</div>
</div>
</body>
</html>
