<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<c:set var="titulo" value="${param.accion == 'buscar' ? 'Buscar producto' : 'Productos'}" />
<c:set var="activo" value="${param.accion == 'buscar' ? 'buscar' : 'listar'}" />
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Productos - ${nombreCorto}</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/estilos.css">
    <link rel="icon" type="image/svg+xml" href="${pageContext.request.contextPath}/img/favicon.svg">
    <script src="${pageContext.request.contextPath}/js/validaciones.js" defer></script>
</head>
<body class="pg-productos">
<div class="app">
<%@ include file="/includes/menu.jsp" %>
<div class="main">
<%@ include file="/includes/header.jsp" %>
<main class="page">

    <section class="panel search-panel" id="buscar">
        <div class="panel-head">
            <h2><svg class="i"><use href="#i-search"/></svg>Buscar producto</h2>
        </div>
        <form class="search-grid" method="get" action="${pageContext.request.contextPath}/productos">
            <input type="hidden" name="accion" value="buscar">
            <div class="field">
                <label for="f-codigo">Código</label>
                <input type="text" id="f-codigo" name="codigo" value="<c:out value='${fCodigo}'/>" placeholder="Ej. P001" ${param.accion == 'buscar' ? 'autofocus' : ''}>
            </div>
            <div class="field">
                <label for="f-nombre">Nombre</label>
                <input type="text" id="f-nombre" name="nombre" value="<c:out value='${fNombre}'/>" placeholder="Nombre del producto">
            </div>
            <div class="field">
                <label for="f-categoria">Categoría</label>
                <select id="f-categoria" name="categoria">
                    <option value="">Todas</option>
                    <c:forEach var="cat" items="${categorias}">
                        <option value="${cat}" ${fCategoria == cat ? 'selected' : ''}>${cat}</option>
                    </c:forEach>
                </select>
            </div>
            <div class="search-actions">
                <button type="submit" class="btn btn-primary"><svg class="i"><use href="#i-search"/></svg>Buscar</button>
                <a class="btn" href="${pageContext.request.contextPath}/productos?accion=buscar">Limpiar</a>
            </div>
        </form>
    </section>

    <section class="panel vista-tabla" id="vista">
        <div class="panel-head">
            <div class="results-head">
                <h2>${filtrado ? 'Resultados' : 'Listado de productos'}</h2>
                <small>${productos.size()} ${productos.size() == 1 ? 'producto' : 'productos'}</small>
            </div>
            <div class="head-tools">
                <div class="seg" role="group" aria-label="Vista">
                    <button type="button" id="btnTabla" class="on" onclick="cambiarVista('tabla')"><svg class="i"><use href="#i-list"/></svg>Tabla</button>
                    <button type="button" id="btnTarjetas" onclick="cambiarVista('tarjetas')"><svg class="i"><use href="#i-grid"/></svg>Tarjetas</button>
                </div>
                <a class="btn btn-accent" href="${pageContext.request.contextPath}/productos?accion=nuevo">
                    <svg class="i"><use href="#i-plus"/></svg>Registrar producto</a>
            </div>
        </div>

        <c:if test="${not empty mensaje}"><div class="alert alert-ok flash"><c:out value="${mensaje}"/></div></c:if>
        <c:if test="${not empty errorGeneral}"><div class="alert alert-error flash"><c:out value="${errorGeneral}"/></div></c:if>

        <div class="table-wrap">
            <table>
                <thead>
                <tr>
                    <th>Código</th><th>Producto</th><th>Categoría</th>
                    <th class="num">Precio</th><th class="num">Stock</th><th>Estado</th><th class="actions">Acciones</th>
                </tr>
                </thead>
                <tbody>
                <c:forEach var="p" items="${productos}">
                    <tr>
                        <td class="code"><c:out value="${p.codigo}"/></td>
                        <td><div class="prod"><%@ include file="/includes/miniatura.jsp" %><c:out value="${p.nombre}"/></div></td>
                        <td><span class="chip cat-${fn:toLowerCase(p.categoria)}"><c:out value="${p.categoria}"/></span></td>
                        <td class="num">S/ <fmt:formatNumber value="${p.precio}" minFractionDigits="2" maxFractionDigits="2"/></td>
                        <td class="num ${p.stock == 0 ? 'zero' : ''}">${p.stock}</td>
                        <td>
                            <span class="badge ${p.estado == 'Disponible' ? 'ok' : (p.estado == 'Agotado' ? 'bad' : 'warn')}"><c:out value="${p.estado}"/></span>
                        </td>
                        <td class="actions">
                            <a class="link" href="${pageContext.request.contextPath}/productos?accion=editar&amp;codigo=<c:out value='${p.codigo}'/>">Editar</a>
                            <button type="button" class="link danger" data-codigo="<c:out value='${p.codigo}'/>" data-nombre="<c:out value='${p.nombre}'/>" onclick="abrirEliminar(this)">Eliminar</button>
                        </td>
                    </tr>
                </c:forEach>
                </tbody>
            </table>
        </div>

        <div class="pgrid-box">
            <div class="pgrid">
                <c:forEach var="p" items="${productos}">
                    <article class="pcard">
                        <div class="pmedia"><%@ include file="/includes/foto.jsp" %>
                            <span class="badge ${p.estado == 'Disponible' ? 'ok' : (p.estado == 'Agotado' ? 'bad' : 'warn')}"><c:out value="${p.estado}"/></span></div>
                        <div class="pbody">
                            <span class="chip cat-${fn:toLowerCase(p.categoria)}"><c:out value="${p.categoria}"/></span>
                            <h3><c:out value="${p.nombre}"/></h3>
                            <div class="pmeta"><span class="code"><c:out value="${p.codigo}"/></span><span class="${p.stock == 0 ? 'zero' : ''}">Stock: ${p.stock}</span></div>
                            <div class="pprice">S/ <fmt:formatNumber value="${p.precio}" minFractionDigits="2" maxFractionDigits="2"/></div>
                        </div>
                        <div class="pactions">
                            <a href="${pageContext.request.contextPath}/productos?accion=editar&amp;codigo=<c:out value='${p.codigo}'/>"><svg class="i"><use href="#i-edit"/></svg>Editar</a>
                            <button type="button" class="danger" data-codigo="<c:out value='${p.codigo}'/>" data-nombre="<c:out value='${p.nombre}'/>" onclick="abrirEliminar(this)"><svg class="i"><use href="#i-trash"/></svg>Eliminar</button>
                        </div>
                    </article>
                </c:forEach>
            </div>
        </div>

        <c:if test="${empty productos}">
            <div class="empty">
                <strong>No se encontraron productos</strong>
                <c:choose>
                    <c:when test="${filtrado}">Pruebe con otro código, nombre o categoría.</c:when>
                    <c:otherwise>Registre el primer producto para comenzar.</c:otherwise>
                </c:choose>
            </div>
        </c:if>
    </section>

</main>
<%@ include file="/includes/footer.jsp" %>
</div>
</div>

<dialog id="dlgEliminar" class="modal">
    <form method="post" action="${pageContext.request.contextPath}/productos">
        <input type="hidden" name="accion" value="eliminar">
        <input type="hidden" name="codigo" id="elCodigo">
        <div class="warn-ic"><svg class="i"><use href="#i-trash"/></svg></div>
        <h3>Eliminar producto</h3>
        <p>Se eliminará <strong id="elNombre"></strong>. Esta acción no se puede deshacer.</p>
        <div class="modal-actions">
            <button type="button" class="btn" onclick="cerrarEliminar()">Cancelar</button>
            <button type="submit" class="btn btn-danger">Eliminar</button>
        </div>
    </form>
</dialog>
</body>
</html>
