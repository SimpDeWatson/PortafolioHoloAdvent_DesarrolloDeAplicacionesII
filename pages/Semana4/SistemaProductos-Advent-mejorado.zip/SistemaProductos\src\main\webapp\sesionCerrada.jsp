<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sesión cerrada - AdventStock</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/estilos.css">
    <link rel="icon" type="image/svg+xml" href="${pageContext.request.contextPath}/img/favicon.svg">
</head>
<body class="pg-sesion">
    <div class="fx-bg" aria-hidden="true"></div>
    <div class="sesion-card">
        <div class="mark">UPLA</div>
        <h1>Sesión cerrada</h1>
        <p>Has cerrado sesión correctamente.</p>
        <a class="btn" href="${pageContext.request.contextPath}/login">Volver a iniciar sesión</a>
    </div>
</body>
</html>
