<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<svg xmlns="http://www.w3.org/2000/svg" style="display:none">
    <symbol id="i-home" viewBox="0 0 24 24"><path d="M3 10.5 12 3l9 7.5V21a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/></symbol>
    <symbol id="i-box" viewBox="0 0 24 24"><path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/><path d="M3.3 7 12 12l8.7-5M12 22V12"/></symbol>
    <symbol id="i-chart" viewBox="0 0 24 24"><path d="M3 3v18h18"/><path d="M7 16v-5M12 16V8M17 16v-9"/></symbol>
    <symbol id="i-info" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 8h.01M11 12h1v4h1"/></symbol>
    <symbol id="i-out" viewBox="0 0 24 24"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/></symbol>
    <symbol id="i-chev" viewBox="0 0 24 24"><path d="m6 9 6 6 6-6"/></symbol>
    <symbol id="i-search" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></symbol>
    <symbol id="i-user" viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"/><path d="M4 20c0-4 3.6-7 8-7s8 3 8 7"/></symbol>
    <symbol id="i-clock" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></symbol>
    <symbol id="i-menu" viewBox="0 0 24 24"><path d="M4 6h16M4 12h16M4 18h16"/></symbol>
    <symbol id="i-plus" viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></symbol>
    <symbol id="i-check" viewBox="0 0 24 24"><path d="M20 6 9 17l-5-5"/></symbol>
    <symbol id="i-edit" viewBox="0 0 24 24"><path d="M12 20h9M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"/></symbol>
    <symbol id="i-trash" viewBox="0 0 24 24"><path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6"/></symbol>
    <symbol id="i-cal" viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M8 3v4M16 3v4M3 10h18"/></symbol>
    <symbol id="i-wallet" viewBox="0 0 24 24"><path d="M20 7H4a2 2 0 0 1 0-4h14v4"/><path d="M4 7v12a2 2 0 0 0 2 2h14a1 1 0 0 0 1-1V8a1 1 0 0 0-1-1"/><path d="M16 13h2"/></symbol>
    <symbol id="i-list" viewBox="0 0 24 24"><path d="M8 6h13M8 12h13M8 18h13M3.5 6h.01M3.5 12h.01M3.5 18h.01"/></symbol>
    <symbol id="i-grid" viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></symbol>
    <symbol id="i-x" viewBox="0 0 24 24"><path d="M18 6 6 18M6 6l12 12"/></symbol>
</svg>

<aside class="sidebar" id="sidebar">
    <div class="brand">
        <span class="mark">UPLA</span>
        <span>${nombreCorto}<small>Gestión de productos</small></span>
    </div>
    <nav class="nav">
        <div class="nav-label">Principal</div>
        <a href="${pageContext.request.contextPath}/index.jsp" class="${activo == 'inicio' ? 'on' : ''}">
            <svg class="i"><use href="#i-home"/></svg>Inicio</a>

        <details ${activo == 'nuevo' || activo == 'listar' || activo == 'buscar' ? 'open' : ''}>
            <summary><svg class="i"><use href="#i-box"/></svg>Productos<svg class="i chev"><use href="#i-chev"/></svg></summary>
            <div class="sub">
                <a href="${pageContext.request.contextPath}/productos?accion=nuevo" class="${activo == 'nuevo' ? 'on' : ''}">Registrar producto</a>
                <a href="${pageContext.request.contextPath}/productos?accion=listar" class="${activo == 'listar' ? 'on' : ''}">Listar productos</a>
                <a href="${pageContext.request.contextPath}/productos?accion=buscar" class="${activo == 'buscar' ? 'on' : ''}">Buscar producto</a>
            </div>
        </details>

        <details ${activo == 'disponibles' || activo == 'resumen' ? 'open' : ''}>
            <summary><svg class="i"><use href="#i-chart"/></svg>Reportes<svg class="i chev"><use href="#i-chev"/></svg></summary>
            <div class="sub">
                <a href="${pageContext.request.contextPath}/reportes?accion=disponibles" class="${activo == 'disponibles' ? 'on' : ''}">Productos disponibles</a>
                <a href="${pageContext.request.contextPath}/reportes?accion=resumen" class="${activo == 'resumen' ? 'on' : ''}">Resumen de productos</a>
            </div>
        </details>

        <a href="${pageContext.request.contextPath}/informacion.jsp" class="${activo == 'info' ? 'on' : ''}">
            <svg class="i"><use href="#i-info"/></svg>Información</a>

        <div class="sep"></div>
        <a href="${pageContext.request.contextPath}/cerrarSesion"><svg class="i"><use href="#i-out"/></svg>Cerrar sesión</a>
    </nav>
    <div class="side-user">
        <div class="avatar" aria-hidden="true">${fn:toUpperCase(fn:substring(usuarioConectado, 0, 1))}</div>
        <div><c:out value="${usuarioConectado}"/><small>Usuario conectado</small></div>
    </div>
</aside>
