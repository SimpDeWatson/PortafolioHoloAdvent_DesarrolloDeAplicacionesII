<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%-- Foto grande del producto "p" para las tarjetas --%>
<c:choose>
    <c:when test="${p.tieneImagen}">
        <c:url var="urlFoto" value="/imagen"><c:param name="codigo" value="${p.codigo}"/></c:url>
        <img class="pimg" src="${urlFoto}" alt="<c:out value='${p.nombre}'/>" loading="lazy">
    </c:when>
    <c:otherwise>
        <div class="pimg ph" aria-hidden="true"><c:out value="${fn:toUpperCase(fn:substring(p.nombre, 0, 1))}"/></div>
    </c:otherwise>
</c:choose>
