/* Validación en el cliente. El servidor (ProductoServlet) valida de forma definitiva. */

function marcar(id, mensaje) {
    var campo = document.getElementById(id);
    var aviso = document.getElementById("err-" + id);
    if (aviso) aviso.textContent = mensaje || "";
    if (campo) campo.classList.toggle("invalid", !!mensaje);
    return !mensaje;
}

var TIPOS_IMAGEN = ["image/png", "image/jpeg", "image/gif", "image/webp"];
var MAX_IMAGEN = 2 * 1024 * 1024;

function errorImagen() {
    var input = document.getElementById("imagen");
    if (!input || !input.files || !input.files.length) return "";
    var archivo = input.files[0];
    if (TIPOS_IMAGEN.indexOf(archivo.type) === -1) return "Seleccione una imagen PNG, JPG, GIF o WEBP.";
    if (archivo.size > MAX_IMAGEN) return "La imagen no puede superar los 2 MB.";
    return "";
}

function validarFormularioProducto() {
    var v = function (id) { return document.getElementById(id).value.trim(); };
    var precio = parseFloat(v("precio"));
    var stock = v("stock");
    var resultados = [
        ["codigo", v("codigo") ? "" : "Ingrese el código."],
        ["nombre", v("nombre") ? "" : "Ingrese el nombre."],
        ["categoria", v("categoria") ? "" : "Seleccione una categoría."],
        ["precio", precio > 0 ? "" : "El precio debe ser mayor que cero."],
        ["stock", /^\d+$/.test(stock) ? "" : "El stock debe ser un entero mayor o igual a cero."],
        ["estado", v("estado") ? "" : "Seleccione un estado."],
        ["imagen", errorImagen()]
    ];
    var primero = null;
    resultados.forEach(function (r) {
        if (!marcar(r[0], r[1]) && !primero) primero = r[0];
    });
    if (primero) document.getElementById(primero).focus();
    return !primero;
}

function abrirEliminar(boton) {
    document.getElementById("elCodigo").value = boton.dataset.codigo;
    document.getElementById("elNombre").textContent = boton.dataset.nombre;
    document.getElementById("dlgEliminar").showModal();
}

function cerrarEliminar() {
    document.getElementById("dlgEliminar").close();
}

function toggleMenu() {
    document.getElementById("sidebar").classList.toggle("open");
}

document.addEventListener("click", function (e) {
    var dlg = document.getElementById("dlgEliminar");
    if (dlg && e.target === dlg) dlg.close();
});

// Al corregir un campo se limpia su error
document.addEventListener("input", function (e) {
    if (e.target.id && document.getElementById("err-" + e.target.id)) marcar(e.target.id, "");
});
document.addEventListener("change", function (e) {
    if (e.target.id && document.getElementById("err-" + e.target.id)) marcar(e.target.id, "");
});

// Fecha y hora actuales (zona horaria de Lima), actualizadas cada segundo
document.addEventListener("DOMContentLoaded", function () {
    var fechas = document.querySelectorAll("[data-fecha]");
    var horas = document.querySelectorAll("[data-hora]");
    if (!fechas.length && !horas.length) return;
    function tick() {
        var ahora = new Date();
        var fecha = ahora.toLocaleDateString("es-PE", { timeZone: "America/Lima", weekday: "long", day: "numeric", month: "long", year: "numeric" });
        var hora = ahora.toLocaleTimeString("es-PE", { timeZone: "America/Lima", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false });
        fechas.forEach(function (el) { el.textContent = fecha; });
        horas.forEach(function (el) { el.textContent = hora; });
    }
    tick();
    setInterval(tick, 1000);
});

// Vista previa de la imagen elegida
document.addEventListener("change", function (e) {
    if (e.target.id !== "imagen") return;
    var previa = document.getElementById("vistaPrevia");
    var error = errorImagen();
    marcar("imagen", error);
    if (!previa) return;
    var archivo = e.target.files && e.target.files[0];
    previa.src = (archivo && !error) ? URL.createObjectURL(archivo) : previa.dataset.original;
    if (error) e.target.value = "";
});

// Cambio de vista del listado: tabla o tarjetas (se recuerda la ultima elegida)
function cambiarVista(vista) {
    var caja = document.getElementById("vista");
    if (!caja) return;
    caja.classList.toggle("vista-tarjetas", vista === "tarjetas");
    caja.classList.toggle("vista-tabla", vista !== "tarjetas");
    document.getElementById("btnTabla").classList.toggle("on", vista !== "tarjetas");
    document.getElementById("btnTarjetas").classList.toggle("on", vista === "tarjetas");
    try { localStorage.setItem("vistaProductos", vista); } catch (e) { /* sin almacenamiento */ }
}

document.addEventListener("DOMContentLoaded", function () {
    var guardada = null;
    try { guardada = localStorage.getItem("vistaProductos"); } catch (e) { /* sin almacenamiento */ }
    if (guardada === "tarjetas") cambiarVista("tarjetas");
});
