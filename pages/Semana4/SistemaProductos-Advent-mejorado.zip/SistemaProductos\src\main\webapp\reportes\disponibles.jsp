<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<c:set var="titulo" value="Productos disponibles" />
<c:set var="activo" value="disponibles" />
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Productos disponibles - ${nombreCorto}</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/estilos.css">
    <link rel="icon" type="image/svg+xml" href="${pageContext.request.contextPath}/img/favicon.svg">
    <script src="${pageContext.request.contextPath}/js/validaciones.js" defer></script>
</head>
<body class="pg-disponibles">
<div class="app">
<%@ include file="/includes/menu.jsp" %>
<div class="main">
<%@ include file="/includes/header.jsp" %>
<main class="page">

    <section class="panel">
        <div class="panel-head">
            <div class="results-head"><h2>Con stock</h2><small>${productos.size()} productos</small></div>
            <a class="btn" href="${pageContext.request.contextPath}/reportes?accion=resumen"><svg class="i"><use href="#i-chart"/></svg>Ver resumen</a>
        </div>
        <div class="panel-body">
            <div class="pgrid">
                <c:forEach var="p" items="${productos}">
                    <article class="pcard">
                        <div class="pmedia"><%@ include file="/includes/foto.jsp" %>
                            <span class="badge ok"><c:out value="${p.estado}"/></span></div>
                        <div class="pbody">
                            <span class="chip cat-${fn:toLowerCase(p.categoria)}"><c:out value="${p.categoria}"/></span>
                            <h3><c:out value="${p.nombre}"/></h3>
                            <div class="pmeta"><span class="code"><c:out value="${p.codigo}"/></span><span>${p.stock} unidades</span></div>
                            <div class="pprice">S/ <fmt:formatNumber value="${p.precio}" minFractionDigits="2" maxFractionDigits="2"/></div>
                        </div>
                    </article>
                </c:forEach>
            </div>
            <c:if test="${empty productos}"><div class="empty"><strong>Sin productos disponibles</strong>Ningún producto tiene stock en este momento.</div></c:if>
        </div>
    </section>

</main>
<%@ include file="/includes/footer.jsp" %>
</div>
</div>
</body>
</html>
