package pe.edu.sistema.controller;

import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;

/**
 * Listener que inicializa datos globales de la aplicación al arrancar el servidor.
 */
@WebListener
public class AppContextListener implements ServletContextListener {

    public static final String NOMBRE_SISTEMA = "Sistema Web de Gestión de Productos";
    public static final String NOMBRE_CORTO = "AdventStock";
    public static final String DESCRIPCION_SISTEMA =
            "Registro, consulta, actualización y control del inventario de productos. Arquitectura MVC.";
    public static final String USUARIO_CONECTADO = "Invitado";

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        sce.getServletContext().setAttribute("nombreSistema", NOMBRE_SISTEMA);
        sce.getServletContext().setAttribute("nombreCorto", NOMBRE_CORTO);
        sce.getServletContext().setAttribute("descripcionSistema", DESCRIPCION_SISTEMA);
        sce.getServletContext().setAttribute("usuarioConectado", USUARIO_CONECTADO);
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        // Nada que limpiar
    }
}
