<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<fmt:setLocale value="es_PE" />
<%
    String _u = (String) application.getAttribute("usuarioConectado");
    String _ini = "";
    if (_u != null && !_u.trim().isEmpty()) {
        String[] _p = _u.trim().split("\\s+");
        _ini = (_p[0].substring(0, 1) + (_p.length > 1 ? _p[1].substring(0, 1) : "")).toUpperCase();
    }
%>
<header class="topbar">
    <button type="button" class="menu-btn" onclick="toggleMenu()" aria-label="Abrir menú"><svg class="i"><use href="#i-menu"/></svg></button>
    <h1>${titulo}</h1>
    <form class="tsearch" method="get" action="${pageContext.request.contextPath}/productos" role="search">
        <input type="hidden" name="accion" value="buscar">
        <svg class="i"><use href="#i-search"/></svg>
        <input type="search" name="nombre" placeholder="Buscar producto por nombre..." aria-label="Buscar producto">
    </form>
    <c:if test="${activo != 'inicio'}">
        <div class="clock"><svg class="i"><use href="#i-clock"/></svg><span class="d" data-fecha></span> <strong data-hora></strong></div>
    </c:if>
    <div class="user">
        <span>${usuarioConectado}</span>
        <div class="avatar" aria-hidden="true"><%= _ini %></div>
    </div>
</header>
