<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%-- Miniatura del producto "p" dentro de un c:forEach --%>
<c:choose>
    <c:when test="${p.tieneImagen}">
        <c:url var="urlImagen" value="/imagen"><c:param name="codigo" value="${p.codigo}"/></c:url>
        <img class="thumb" src="${urlImagen}" alt="" loading="lazy">
    </c:when>
    <c:otherwise>
        <span class="thumb ph" aria-hidden="true"><c:out value="${fn:toUpperCase(fn:substring(p.nombre, 0, 1))}"/></span>
    </c:otherwise>
</c:choose>
