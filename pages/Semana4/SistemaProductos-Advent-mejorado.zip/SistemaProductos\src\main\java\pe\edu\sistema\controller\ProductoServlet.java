package pe.edu.sistema.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;
import pe.edu.sistema.model.Producto;
import pe.edu.sistema.service.ProductoService;

import java.io.IOException;
import java.io.InputStream;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Controlador (Servlet) del modulo de Productos.
 * Gestiona: listar, buscar, mostrar formulario (nuevo/editar), guardar,
 * actualizar y eliminar. Toda la informacion se guarda en memoria a traves
 * de ProductoService (ArrayList), sin usar base de datos.
 */
@WebServlet("/productos")
@MultipartConfig(maxFileSize = 10 * 1024 * 1024, maxRequestSize = 12 * 1024 * 1024)
public class ProductoServlet extends HttpServlet {

    private static final long MAX_IMAGEN = 2L * 1024 * 1024; // 2 MB

    private final ProductoService service = ProductoService.getInstancia();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        procesar(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        procesar(request, response);
    }

    private void procesar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String accion = request.getParameter("accion");
        if (accion == null || accion.trim().isEmpty()) {
            accion = "listar";
        }

        switch (accion) {
            case "nuevo":
                mostrarFormularioNuevo(request, response);
                break;
            case "guardar":
                guardar(request, response);
                break;
            case "editar":
                mostrarFormularioEditar(request, response);
                break;
            case "actualizar":
                actualizar(request, response);
                break;
            case "eliminar":
                eliminar(request, response);
                break;
            case "buscar":
                buscar(request, response);
                break;
            case "listar":
            default:
                listar(request, response);
                break;
        }
    }

    // ==================== LISTAR ====================
    private void listar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        mostrarMensajePendiente(request);
        request.setAttribute("productos", service.listarTodos());
        request.setAttribute("categorias", ProductoService.CATEGORIAS);
        forward(request, response, "/productos/listar.jsp");
    }

    // ==================== BUSCAR ====================
    private void buscar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String codigo = trim(request.getParameter("codigo"));
        String nombre = trim(request.getParameter("nombre"));
        String categoria = trim(request.getParameter("categoria"));

        request.setAttribute("productos", service.buscar(codigo, nombre, categoria));
        request.setAttribute("fCodigo", codigo);
        request.setAttribute("fNombre", nombre);
        request.setAttribute("fCategoria", categoria);
        request.setAttribute("filtrado", !codigo.isEmpty() || !nombre.isEmpty() || !categoria.isEmpty());
        request.setAttribute("categorias", ProductoService.CATEGORIAS);
        forward(request, response, "/productos/listar.jsp");
    }

    // ==================== FORMULARIO NUEVO ====================
    private void mostrarFormularioNuevo(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setAttribute("modo", "nuevo");
        request.setAttribute("producto", new Producto());
        request.setAttribute("categorias", ProductoService.CATEGORIAS);
        request.setAttribute("estados", ProductoService.ESTADOS);
        forward(request, response, "/productos/formulario.jsp");
    }

    // ==================== FORMULARIO EDITAR ====================
    private void mostrarFormularioEditar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String codigo = request.getParameter("codigo");
        Producto producto = service.buscarPorCodigo(codigo);

        if (producto == null) {
            request.setAttribute("errorGeneral", "No se encontró el producto con código \"" + codigo + "\".");
            listar(request, response);
            return;
        }

        request.setAttribute("modo", "editar");
        request.setAttribute("producto", producto);
        request.setAttribute("categorias", ProductoService.CATEGORIAS);
        request.setAttribute("estados", ProductoService.ESTADOS);
        forward(request, response, "/productos/formulario.jsp");
    }

    // ==================== GUARDAR (nuevo producto) ====================
    private void guardar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        Producto producto = leerProductoDelFormulario(request);
        Map<String, String> errores = validar(producto, true);
        boolean conImagen = leerImagen(request, producto, errores);

        if (!errores.isEmpty()) {
            request.setAttribute("avisoImagen", conImagen && !errores.containsKey("imagen"));
            request.setAttribute("errores", errores);
            request.setAttribute("modo", "nuevo");
            request.setAttribute("producto", producto);
            request.setAttribute("categorias", ProductoService.CATEGORIAS);
            request.setAttribute("estados", ProductoService.ESTADOS);
            forward(request, response, "/productos/formulario.jsp");
            return;
        }

        service.agregar(producto);
        redirigirConMensaje(request, response, "Producto \"" + producto.getNombre() + "\" registrado.");
    }

    // ==================== ACTUALIZAR (editar producto) ====================
    private void actualizar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        Producto producto = leerProductoDelFormulario(request);
        Map<String, String> errores = validar(producto, false);
        boolean conImagen = leerImagen(request, producto, errores);

        // Si no se eligio una imagen nueva, se muestra (y se conserva) la actual
        Producto existente = service.buscarPorCodigo(producto.getCodigo());
        if (!producto.isTieneImagen() && existente != null) {
            producto.setImagen(existente.getImagen());
            producto.setImagenTipo(existente.getImagenTipo());
        }

        if (!errores.isEmpty()) {
            request.setAttribute("avisoImagen", conImagen && !errores.containsKey("imagen"));
            request.setAttribute("errores", errores);
            request.setAttribute("modo", "editar");
            request.setAttribute("producto", producto);
            request.setAttribute("categorias", ProductoService.CATEGORIAS);
            request.setAttribute("estados", ProductoService.ESTADOS);
            forward(request, response, "/productos/formulario.jsp");
            return;
        }

        service.actualizar(producto);
        redirigirConMensaje(request, response, "Producto \"" + producto.getNombre() + "\" actualizado.");
    }

    // ==================== ELIMINAR ====================
    private void eliminar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String codigo = request.getParameter("codigo");
        boolean eliminado = service.eliminar(codigo);

        if (eliminado) {
            redirigirConMensaje(request, response, "Producto " + codigo + " eliminado.");
        } else {
            request.setAttribute("errorGeneral", "No se pudo eliminar: el producto " + codigo + " no existe.");
            listar(request, response);
        }
    }

    // ==================== UTILIDADES ====================

    /** Patron Post/Redirect/Get: evita reenviar el formulario al recargar la pagina. */
    private void redirigirConMensaje(HttpServletRequest request, HttpServletResponse response, String mensaje)
            throws IOException {
        request.getSession().setAttribute("flash", mensaje);
        response.sendRedirect(request.getContextPath() + "/productos?accion=listar");
    }

    private void mostrarMensajePendiente(HttpServletRequest request) {
        HttpSession sesion = request.getSession(false);
        if (sesion != null && sesion.getAttribute("flash") != null) {
            request.setAttribute("mensaje", sesion.getAttribute("flash"));
            sesion.removeAttribute("flash");
        }
    }

    private Producto leerProductoDelFormulario(HttpServletRequest request) {
        Producto p = new Producto();
        p.setCodigo(trim(request.getParameter("codigo")).toUpperCase());
        p.setNombre(trim(request.getParameter("nombre")));
        p.setCategoria(trim(request.getParameter("categoria")));
        p.setEstado(trim(request.getParameter("estado")));

        String precioStr = trim(request.getParameter("precio"));
        String stockStr = trim(request.getParameter("stock"));

        // Guardamos el texto "crudo" para poder re-mostrarlo si hay error de formato
        p.setPrecio(parseDoubleSeguro(precioStr));
        p.setStock(parseIntSeguro(stockStr));

        request.setAttribute("precioTexto", precioStr);
        request.setAttribute("stockTexto", stockStr);

        return p;
    }

    /**
     * Lee la imagen enviada en el formulario (campo "imagen"), la valida (tamano y
     * formato real segun sus primeros bytes) y la asigna al producto.
     * Devuelve true si el usuario selecciono un archivo.
     */
    private boolean leerImagen(HttpServletRequest request, Producto p, Map<String, String> errores)
            throws IOException, ServletException {
        String contentType = request.getContentType();
        if (contentType == null || !contentType.toLowerCase().startsWith("multipart/")) {
            return false;
        }
        Part parte = request.getPart("imagen");
        if (parte == null || parte.getSize() == 0) {
            return false;
        }
        if (parte.getSize() > MAX_IMAGEN) {
            errores.put("imagen", "La imagen no puede superar los 2 MB.");
            return true;
        }
        byte[] datos;
        try (InputStream in = parte.getInputStream()) {
            datos = in.readAllBytes();
        }
        String tipo = detectarTipoImagen(datos);
        if (tipo == null) {
            errores.put("imagen", "Seleccione una imagen PNG, JPG, GIF o WEBP.");
            return true;
        }
        p.setImagen(datos);
        p.setImagenTipo(tipo);
        return true;
    }

    /** Identifica el formato por los primeros bytes del archivo (no por su extension). */
    private String detectarTipoImagen(byte[] b) {
        if (b.length >= 8 && (b[0] & 0xFF) == 0x89 && b[1] == 'P' && b[2] == 'N' && b[3] == 'G') {
            return "image/png";
        }
        if (b.length >= 3 && (b[0] & 0xFF) == 0xFF && (b[1] & 0xFF) == 0xD8) {
            return "image/jpeg";
        }
        if (b.length >= 4 && b[0] == 'G' && b[1] == 'I' && b[2] == 'F' && b[3] == '8') {
            return "image/gif";
        }
        if (b.length >= 12 && b[0] == 'R' && b[1] == 'I' && b[2] == 'F' && b[3] == 'F'
                && b[8] == 'W' && b[9] == 'E' && b[10] == 'B' && b[11] == 'P') {
            return "image/webp";
        }
        return null;
    }

    private double parseDoubleSeguro(String texto) {
        try {
            return Double.parseDouble(texto.replace(",", "."));
        } catch (Exception e) {
            return -1;
        }
    }

    private int parseIntSeguro(String texto) {
        try {
            return Integer.parseInt(texto);
        } catch (Exception e) {
            return -1;
        }
    }

    private String trim(String texto) {
        return texto == null ? "" : texto.trim();
    }

    /**
     * Valida los datos del producto y devuelve un mapa campo -> mensaje de error.
     * Si el mapa esta vacio, los datos son validos. Si "esNuevo" es true,
     * tambien valida que el codigo no este duplicado.
     */
    private Map<String, String> validar(Producto p, boolean esNuevo) {
        Map<String, String> errores = new LinkedHashMap<>();

        if (p.getCodigo().isEmpty()) {
            errores.put("codigo", "Ingrese el código del producto.");
        } else if (esNuevo && service.existeCodigo(p.getCodigo())) {
            errores.put("codigo", "El código " + p.getCodigo() + " ya está registrado.");
        }

        if (p.getNombre().isEmpty()) {
            errores.put("nombre", "Ingrese el nombre del producto.");
        }

        if (p.getCategoria().isEmpty()) {
            errores.put("categoria", "Seleccione una categoría.");
        }

        if (p.getEstado().isEmpty()) {
            errores.put("estado", "Seleccione un estado.");
        }

        if (p.getPrecio() <= 0) {
            errores.put("precio", "El precio debe ser mayor que cero.");
        }

        if (p.getStock() < 0) {
            errores.put("stock", "El stock debe ser un entero mayor o igual a cero.");
        }

        return errores;
    }

    private void forward(HttpServletRequest request, HttpServletResponse response, String ruta)
            throws ServletException, IOException {
        RequestDispatcher rd = request.getRequestDispatcher(ruta);
        rd.forward(request, response);
    }
}
