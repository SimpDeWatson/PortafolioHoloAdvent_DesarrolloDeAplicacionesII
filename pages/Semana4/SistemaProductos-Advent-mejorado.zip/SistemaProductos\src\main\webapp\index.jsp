<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<%@ page import="pe.edu.sistema.service.ProductoService" %>
<c:set var="titulo" value="Inicio" />
<c:set var="activo" value="inicio" />
<%
    int _hora = java.time.LocalTime.now(java.time.ZoneId.of("America/Lima")).getHour();
    String _saludo = _hora < 12 ? "Buenos días" : (_hora < 19 ? "Buenas tardes" : "Buenas noches");
    String _nombre = String.valueOf(application.getAttribute("usuarioConectado")).split("\\s+")[0];
    ProductoService _svc = ProductoService.getInstancia();
    int _total = _svc.contarTotalProductos();
    java.util.List<pe.edu.sistema.model.Producto> _todos = _svc.listarTodos();
    java.util.List<pe.edu.sistema.model.Producto> _rec =
            new java.util.ArrayList<>(_todos.subList(Math.max(0, _todos.size() - 4), _todos.size()));
    java.util.Collections.reverse(_rec);
    request.setAttribute("recientes", _rec);
    request.setAttribute("totalProductos", _total);
    request.setAttribute("totalDisponibles", _svc.contarDisponibles());
    request.setAttribute("totalAgotados", _svc.contarAgotados());
    request.setAttribute("valorInventario", _svc.calcularValorTotalInventario());
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Inicio - ${nombreCorto}</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/estilos.css">
    <link rel="icon" type="image/svg+xml" href="${pageContext.request.contextPath}/img/favicon.svg">
    <script src="${pageContext.request.contextPath}/js/validaciones.js" defer></script>
</head>
<body class="pg-inicio">
<div class="app">
<%@ include file="/includes/menu.jsp" %>
<div class="main">
<%@ include file="/includes/header.jsp" %>
<main class="page">

    <fmt:timeZone value="America/Lima">
        <fmt:formatDate value="<%= new java.util.Date() %>" pattern="EEEE d 'de' MMMM 'de' yyyy" var="fechaHoy" />
    </fmt:timeZone>

    <section class="banner">
        <span class="eyebrow">Panel de control</span>
        <h2><%= _saludo %>, <%= _nombre %></h2>
        <p><strong>${nombreSistema}.</strong> ${descripcionSistema}</p>
        <div class="chips">
            <span><svg class="i"><use href="#i-user"/></svg>Usuario conectado: <strong>${usuarioConectado}</strong></span>
            <span><svg class="i"><use href="#i-cal"/></svg><b class="date" data-fecha>${fechaHoy}</b></span>
            <span><svg class="i"><use href="#i-clock"/></svg><b data-hora></b></span>
        </div>
        <div class="banner-actions">
            <a class="btn btn-white" href="${pageContext.request.contextPath}/productos?accion=nuevo"><svg class="i"><use href="#i-plus"/></svg>Registrar producto</a>
            <a class="btn btn-light" href="${pageContext.request.contextPath}/productos?accion=listar">Ver listado</a>
        </div>
    </section>

    <section class="kpis">
        <div class="kpi"><span class="ic"><svg class="i"><use href="#i-box"/></svg></span>
            <div><div class="lbl">Productos registrados</div><div class="val">${totalProductos}</div></div></div>
        <div class="kpi"><span class="ic"><svg class="i"><use href="#i-check"/></svg></span>
            <div><div class="lbl">Disponibles</div><div class="val">${totalDisponibles}</div></div></div>
        <div class="kpi"><span class="ic"><svg class="i"><use href="#i-x"/></svg></span>
            <div><div class="lbl">Agotados</div><div class="val">${totalAgotados}</div></div></div>
        <div class="kpi"><span class="ic"><svg class="i"><use href="#i-wallet"/></svg></span>
            <div><div class="lbl">Valor del inventario</div><div class="val"><small>S/</small> <fmt:formatNumber value="${valorInventario}" minFractionDigits="2" maxFractionDigits="2"/></div></div></div>
    </section>

    <h2 class="section-title">Accesos rápidos</h2>
    <div class="tiles">
        <a class="tile" href="${pageContext.request.contextPath}/productos?accion=nuevo"><span class="ic"><svg class="i"><use href="#i-plus"/></svg></span><span>Registrar producto<small>Agregar un nuevo producto</small></span></a>
        <a class="tile" href="${pageContext.request.contextPath}/productos?accion=listar"><span class="ic"><svg class="i"><use href="#i-list"/></svg></span><span>Listar productos<small>Editar o eliminar</small></span></a>
        <a class="tile" href="${pageContext.request.contextPath}/reportes?accion=disponibles"><span class="ic"><svg class="i"><use href="#i-check"/></svg></span><span>Productos disponibles<small>Solo con stock</small></span></a>
        <a class="tile" href="${pageContext.request.contextPath}/reportes?accion=resumen"><span class="ic"><svg class="i"><use href="#i-chart"/></svg></span><span>Resumen de productos<small>Totales e inventario</small></span></a>
    </div>

    <c:if test="${not empty recientes}">
        <h2 class="section-title">Últimos productos registrados <a href="${pageContext.request.contextPath}/productos?accion=listar">Ver todos &rarr;</a></h2>
        <div class="pgrid">
            <c:forEach var="p" items="${recientes}">
                <article class="pcard">
                    <div class="pmedia"><%@ include file="/includes/foto.jsp" %>
                        <span class="badge ${p.stock > 0 ? 'ok' : 'bad'}"><c:out value="${p.estado}"/></span></div>
                    <div class="pbody">
                        <span class="chip cat-${fn:toLowerCase(p.categoria)}"><c:out value="${p.categoria}"/></span>
                        <h3><c:out value="${p.nombre}"/></h3>
                        <div class="pmeta"><span class="code"><c:out value="${p.codigo}"/></span><span>Stock: ${p.stock}</span></div>
                        <div class="pprice">S/ <fmt:formatNumber value="${p.precio}" minFractionDigits="2" maxFractionDigits="2"/></div>
                    </div>
                </article>
            </c:forEach>
        </div>
    </c:if>

</main>
<%@ include file="/includes/footer.jsp" %>
</div>
</div>
</body>
</html>
