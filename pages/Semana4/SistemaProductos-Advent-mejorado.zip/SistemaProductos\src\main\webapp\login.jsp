<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Iniciar sesión - AdventStock</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/estilos.css">
    <link rel="icon" type="image/svg+xml" href="${pageContext.request.contextPath}/img/favicon.svg">
</head>
<body class="pg-login">
    <div class="fx-bg" aria-hidden="true"></div>
    <div class="login-card">
        <div class="logo">
            <div class="mark">UPLA</div>
            <div>
                <div class="tit">AdventStock</div>
                <div class="subt">Universidad Peruana Los Andes</div>
            </div>
        </div>
        <h1>Iniciar sesión</h1>
        <p class="sub">Ingresa tus credenciales para continuar</p>

        <c:if test="${not empty error}">
            <div class="error-msg">${error}</div>
        </c:if>

        <form method="post" action="${pageContext.request.contextPath}/login">
            <label for="usuario">Usuario</label>
            <input type="text" id="usuario" name="usuario" placeholder="Ej. Adrian" required autofocus autocomplete="username">

            <label for="clave">Contraseña</label>
            <input type="password" id="clave" name="clave" placeholder="••••••••" required autocomplete="current-password">

            <button type="submit" class="btn-login">Entrar al sistema</button>
        </form>

        <p class="hint-login">Usuario: <strong>Adrian</strong> &nbsp;|&nbsp; Contraseña: <strong>hololive2026</strong></p>
        <p class="login-tag">hololive english &mdash; Advent</p>
    </div>
</body>
</html>
