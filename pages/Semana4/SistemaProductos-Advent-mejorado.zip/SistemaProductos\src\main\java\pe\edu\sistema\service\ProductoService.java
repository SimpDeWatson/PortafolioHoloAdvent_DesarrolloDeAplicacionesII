package pe.edu.sistema.service;

import pe.edu.sistema.model.Producto;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Capa de servicio (lógica de negocio) del Sistema de Gestión de Productos.
 * Almacenamiento EN MEMORIA con ArrayList (sin base de datos).
 */
public class ProductoService {

    private static final ProductoService INSTANCIA = new ProductoService();
    private final List<Producto> productos = new ArrayList<>();

    public static final String[] CATEGORIAS = {
            "Computadoras",
            "Accesorios",
            "Impresoras",
            "Monitores",
            "Audio",
            "Otros"
    };

    public static final String[] ESTADOS = {
            "Disponible",
            "Agotado",
            "Descontinuado"
    };

    private ProductoService() {
        cargarDatosDeEjemplo();
    }

    public static ProductoService getInstancia() {
        return INSTANCIA;
    }

    private void cargarDatosDeEjemplo() {
        // Productos de ejemplo (estilo electrónicos) - más de 6
        productos.add(conImagen(new Producto("P001", "Laptop Lenovo IdeaPad", "Computadoras", 2500.00, 10, "Disponible"), "p001"));
        productos.add(conImagen(new Producto("P002", "Mouse Logitech M170", "Accesorios", 80.00, 25, "Disponible"), "p002"));
        productos.add(conImagen(new Producto("P003", "Teclado Redragon Kumara", "Accesorios", 150.00, 0, "Agotado"), "p003"));
        productos.add(conImagen(new Producto("P004", "Monitor Samsung 24\"", "Monitores", 760.00, 8, "Disponible"), "p004"));
        productos.add(conImagen(new Producto("P005", "Impresora Epson L3250", "Impresoras", 920.00, 4, "Disponible"), "p005"));
        productos.add(conImagen(new Producto("P006", "Webcam Logitech C920", "Accesorios", 340.00, 12, "Disponible"), "p006"));
        productos.add(conImagen(new Producto("P007", "Auriculares HyperX Cloud", "Audio", 280.00, 15, "Disponible"), "p007"));
        productos.add(conImagen(new Producto("P008", "SSD Kingston 1TB", "Accesorios", 320.00, 20, "Disponible"), "p008"));
        productos.add(conImagen(new Producto("P009", "Laptop HP Pavilion 15", "Computadoras", 3100.00, 5, "Disponible"), "p009"));
        productos.add(conImagen(new Producto("P010", "Mouse Razer DeathAdder", "Accesorios", 210.00, 0, "Agotado"), "p010"));
        productos.add(conImagen(new Producto("P011", "Monitor LG UltraWide 29\"", "Monitores", 1450.00, 3, "Disponible"), "p011"));
        productos.add(conImagen(new Producto("P012", "Teclado Mecánico Keychron K2", "Accesorios", 480.00, 7, "Disponible"), "p012"));
        productos.add(conImagen(new Producto("P013", "Impresora HP DeskJet 2775", "Impresoras", 450.00, 0, "Agotado"), "p013"));
        productos.add(conImagen(new Producto("P014", "Parlantes Logitech Z313", "Audio", 190.00, 18, "Disponible"), "p014"));
        productos.add(conImagen(new Producto("P015", "Laptop ASUS VivoBook", "Computadoras", 2750.00, 6, "Disponible"), "p015"));
        productos.add(conImagen(new Producto("P016", "Hub USB-C 7 en 1", "Accesorios", 95.00, 30, "Disponible"), "p016"));
        productos.add(conImagen(new Producto("P017", "Monitor Dell 27\"", "Monitores", 980.00, 2, "Disponible"), "p017"));
        productos.add(conImagen(new Producto("P018", "Micrófono Blue Yeti", "Audio", 520.00, 0, "Agotado"), "p018"));
        productos.add(conImagen(new Producto("P019", "Laptop Acer Aspire 5", "Computadoras", 2300.00, 9, "Disponible"), "p019"));
        productos.add(conImagen(new Producto("P020", "Mousepad XXL RGB", "Accesorios", 65.00, 40, "Disponible"), "p020"));
    }

    private Producto conImagen(Producto p, String base) {
        String[][] formatos = {
            {"jpg", "image/jpeg"}, {"jpeg", "image/jpeg"}, {"png", "image/png"},
            {"webp", "image/webp"}
        };
        for (String[] formato : formatos) {
            try (java.io.InputStream in = ProductoService.class
                    .getResourceAsStream("/imagenes/" + base + "." + formato[0])) {
                if (in != null) {
                    p.setImagen(in.readAllBytes());
                    p.setImagenTipo(formato[1]);
                    return p;
                }
            } catch (java.io.IOException e) {
                // continuar
            }
        }
        return p;
    }

    // ================== OPERACIONES CRUD ==================

    public List<Producto> listarTodos() {
        return new ArrayList<>(productos);
    }

    public Producto buscarPorCodigo(String codigo) {
        if (codigo == null) return null;
        return productos.stream()
                .filter(p -> p.getCodigo().equalsIgnoreCase(codigo.trim()))
                .findFirst()
                .orElse(null);
    }

    public List<Producto> buscar(String codigo, String nombre, String categoria) {
        return productos.stream()
                .filter(p -> codigo == null || codigo.isBlank() || p.getCodigo().toLowerCase().contains(codigo.toLowerCase().trim()))
                .filter(p -> nombre == null || nombre.isBlank() || p.getNombre().toLowerCase().contains(nombre.toLowerCase().trim()))
                .filter(p -> categoria == null || categoria.isBlank() || "Todas las categorías".equals(categoria) || p.getCategoria().equalsIgnoreCase(categoria))
                .collect(Collectors.toList());
    }

    public List<Producto> listarDisponibles() {
        return productos.stream()
                .filter(p -> p.getStock() > 0 && "Disponible".equalsIgnoreCase(p.getEstado()))
                .collect(Collectors.toList());
    }

    public synchronized boolean registrar(Producto nuevo) {
        if (buscarPorCodigo(nuevo.getCodigo()) != null) {
            return false; // código duplicado
        }
        productos.add(nuevo);
        return true;
    }

    public synchronized boolean actualizar(Producto actualizado) {
        for (int i = 0; i < productos.size(); i++) {
            if (productos.get(i).getCodigo().equalsIgnoreCase(actualizado.getCodigo())) {
                productos.set(i, actualizado);
                return true;
            }
        }
        return false;
    }

    public synchronized boolean eliminar(String codigo) {
        return productos.removeIf(p -> p.getCodigo().equalsIgnoreCase(codigo));
    }

    public int totalProductos() {
        return productos.size();
    }

    public int totalDisponibles() {
        return (int) productos.stream().filter(p -> p.getStock() > 0).count();
    }

    public int totalAgotados() {
        return (int) productos.stream().filter(p -> p.getStock() <= 0).count();
    }

    public double valorTotalInventario() {
        return productos.stream().mapToDouble(Producto::getValorInventario).sum();
    }

    public int stockTotal() {
        return productos.stream().mapToInt(Producto::getStock).sum();
    }

    /** Alias de registrar (usado por ProductoServlet) */
    public synchronized void agregar(Producto producto) {
        registrar(producto);
    }

    /** Verifica si ya existe un producto con ese código */
    public boolean existeCodigo(String codigo) {
        return buscarPorCodigo(codigo) != null;
    }

    // Alias para compatibilidad con las JSP y Servlets existentes
    public int contarTotalProductos() { return totalProductos(); }
    public int contarDisponibles() { return totalDisponibles(); }
    public int contarAgotados() { return totalAgotados(); }
    public double calcularValorTotalInventario() { return valorTotalInventario(); }
    public int calcularStockTotal() { return stockTotal(); }
}
