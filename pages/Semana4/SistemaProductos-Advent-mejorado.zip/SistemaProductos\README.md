# AdventStock - Sistema Web de Gestión de Productos

Proyecto web **Java 17 + JSP + Servlets + Maven** para **Apache Tomcat 11**, siguiendo el patrón **MVC**.

Tema visual inspirado en **Hololive Advent** (oscuro, púrpura y magenta).

## Credenciales de acceso

| Campo        | Valor         |
|--------------|---------------|
| Usuario      | `Adrian`      |
| Contraseña   | `hololive2026`|

## Cómo abrirlo en NetBeans

1. Abre **NetBeans**.
2. Ve a **File → Open Project...**
3. Selecciona la carpeta `SistemaProductos` (la que contiene el `pom.xml`).
4. Asegúrate de tener configurado:
   - **JDK 17** o superior
   - **Apache Tomcat 11** (Tools → Servers)
5. Clic derecho en el proyecto → **Clean and Build**
6. Clic derecho → **Run**

El navegador se abrirá en:
`http://localhost:8080/SistemaProductos/`

Serás redirigido al **login**. Usa las credenciales de arriba.

## Cómo ejecutarlo por línea de comandos

```bash
mvn clean package
# se genera target/SistemaProductos.war
# cópialo a la carpeta webapps/ de Tomcat 11 y arranca el servidor
```

## Funcionalidades

- Login con autenticación (Adrian / hololive2026)
- Inicio (dashboard con resumen)
- Registrar / Listar / Buscar / Editar / Eliminar productos
- Reportes: Productos disponibles + Resumen
- Página de Información
- 20 productos de ejemplo precargados
- Almacenamiento en memoria (ArrayList) – sin base de datos

## Estructura MVC

```
model/     → Producto.java
service/   → ProductoService.java (ArrayList + reglas)
controller/→ ProductoServlet, ReporteServlet, LoginServlet, AuthFilter...
webapp/    → JSP + CSS + JS
```

## Diseño visual (tema hololive ENGLISH -Advent-)

- **Fondos oficiales de Advent** en cada página con velo opaco para legibilidad
  (`webapp/img/fondos/`): inicio, productos, formulario, reportes, información, login y sesión cerrada.
- **Glassmorphism**: paneles, sidebar y topbar translúcidos con desenfoque (`backdrop-filter`).
- **Efectos**: entradas escalonadas, brillo pulsante en el logo, destello al pasar por botones,
  zoom lento (Ken Burns) y partículas en login, orbes de luz flotantes, barras y donut animados.
- **Paleta Advent**: púrpura `#8b5cf6`, magenta `#ec4899`, hielo `#7dd3fc` sobre noche `#0a0714`.
- **Imágenes de producto** estilo e-commerce con iluminación neón para los 20 productos
  (`resources/imagenes/p001` … `p020`).

