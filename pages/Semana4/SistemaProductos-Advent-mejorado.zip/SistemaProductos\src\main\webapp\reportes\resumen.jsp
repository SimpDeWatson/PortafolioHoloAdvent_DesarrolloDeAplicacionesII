<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<c:set var="titulo" value="Resumen de productos" />
<c:set var="activo" value="resumen" />
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Resumen de productos - ${nombreCorto}</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/estilos.css">
    <link rel="icon" type="image/svg+xml" href="${pageContext.request.contextPath}/img/favicon.svg">
    <script src="${pageContext.request.contextPath}/js/validaciones.js" defer></script>
</head>
<body class="pg-resumen">
<div class="app">
<%@ include file="/includes/menu.jsp" %>
<div class="main">
<%@ include file="/includes/header.jsp" %>
<main class="page">

    <fmt:formatNumber var="pct" value="${totalProductos == 0 ? 0 : totalDisponibles * 100 / totalProductos}" maxFractionDigits="0" groupingUsed="false"/>

    <div class="rep">
        <section class="panel donut-box">
            <h2 style="margin:0 0 18px;font-size:16px">Disponibilidad</h2>
            <div class="donut" style="--pct:${pct}"><div><b>${pct}%</b><small>con stock</small></div></div>
            <div class="legend">
                <span><i style="background:var(--teal)"></i>Disponibles (${totalDisponibles})</span>
                <span><i style="background:#ffd6e2"></i>Agotados (${totalAgotados})</span>
            </div>
        </section>

        <div class="stats">
            <div class="stat"><div class="label">Total de productos</div><div class="value">${totalProductos}</div></div>
            <div class="stat"><div class="label">Productos disponibles</div><div class="value">${totalDisponibles}</div></div>
            <div class="stat"><div class="label">Productos agotados</div><div class="value">${totalAgotados}</div></div>
            <div class="stat"><div class="label">Stock total</div><div class="value">${stockTotal} <small>unidades</small></div></div>
            <div class="stat wide"><div class="label">Valor total del inventario</div>
                <div class="value">S/ <fmt:formatNumber value="${valorInventario}" minFractionDigits="2" maxFractionDigits="2"/></div></div>
        </div>
    </div>

    <c:if test="${not empty porCategoria}">
        <section class="panel" style="margin-top:22px">
            <div class="panel-head"><h2>Productos por categoría</h2></div>
            <div class="bars">
                <c:forEach var="e" items="${porCategoria}">
                    <div class="bar">
                        <span><c:out value="${e.key}"/></span>
                        <span class="track"><span class="fill" style="width:${totalProductos == 0 ? 0 : e.value * 100 / totalProductos}%"></span></span>
                        <b>${e.value}</b>
                    </div>
                </c:forEach>
            </div>
        </section>
    </c:if>

</main>
<%@ include file="/includes/footer.jsp" %>
</div>
</div>
</body>
</html>
