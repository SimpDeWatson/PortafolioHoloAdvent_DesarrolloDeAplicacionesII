<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<footer class="foot">
    <span>&copy; 2026 <b>${nombreCorto}</b> &middot; Sistema Web de Gestión de Productos</span>
    <span>Versión 1.0.0 &middot; Java, JSP, Servlets y Maven &middot; Apache Tomcat 11</span>
</footer>
