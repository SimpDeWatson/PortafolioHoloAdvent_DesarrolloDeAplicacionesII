package pe.edu.sistema.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import pe.edu.sistema.model.Producto;
import pe.edu.sistema.service.ProductoService;

import java.io.IOException;

/**
 * Controlador que entrega la imagen de un producto: /imagen?codigo=P001.
 * Las imagenes se guardan en memoria junto al producto (sin base de datos).
 */
@WebServlet("/imagen")
public class ImagenServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Producto producto = ProductoService.getInstancia().buscarPorCodigo(request.getParameter("codigo"));

        if (producto == null || !producto.isTieneImagen()) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }
        response.setContentType(producto.getImagenTipo());
        response.setContentLength(producto.getImagen().length);
        response.setHeader("Cache-Control", "no-cache");
        response.setHeader("X-Content-Type-Options", "nosniff");
        response.getOutputStream().write(producto.getImagen());
    }
}
