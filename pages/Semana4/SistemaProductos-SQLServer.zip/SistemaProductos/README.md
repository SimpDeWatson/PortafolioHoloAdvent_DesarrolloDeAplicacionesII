# AdventStock - Sistema Web de Gestión de Productos (SQL Server)

Java 17 + JSP + Servlets + Maven + **Microsoft SQL Server** + Tomcat 11 | Arquitectura MVC

## 1. Crear la base de datos (obligatorio)

1. Abre **SQL Server Management Studio (SSMS)**
2. Conéctate a tu instancia (`localhost`, `.\SQLEXPRESS`, etc.)
3. Abre el archivo:
   `src/main/resources/db/00_crear_base_datos.sql`
4. Ejecútalo completo (F5)

Eso crea:
- Base de datos `AdventStock`
- Tabla `productos`
- Tabla `usuarios`
- 20 productos de ejemplo
- Usuario `Adrian` / `hololive2026`

## 2. Configurar la conexión

Edita el archivo:

`src/main/resources/db.properties`

```properties
db.server=localhost
db.port=1433
db.name=AdventStock
db.user=sa
db.password=TuPassword123
db.integratedSecurity=false
```

| Si usas... | Qué poner |
|------------|-----------|
| SQL Server Express | `db.server=.\\SQLEXPRESS` o `localhost\\SQLEXPRESS` |
| Autenticación Windows | `db.integratedSecurity=true` y deja user/password vacíos |
| Puerto distinto | Cambia `db.port` |

## 3. Abrir en NetBeans

1. File → Open Project → carpeta `SistemaProductos`
2. JDK 17 + Tomcat 11
3. Clean and Build → Run

URL: `http://localhost:8080/SistemaProductos/`

Login: **Adrian** / **hololive2026**

## Tablas

### productos
| Columna | Tipo |
|---------|------|
| codigo (PK) | VARCHAR(20) |
| nombre | VARCHAR(150) |
| categoria | VARCHAR(50) |
| precio | DECIMAL(12,2) |
| stock | INT |
| estado | VARCHAR(30) |
| imagen | VARBINARY(MAX) |
| imagen_tipo | VARCHAR(50) |

### usuarios
| Columna | Tipo |
|---------|------|
| id (PK Identity) | INT |
| username | VARCHAR(50) UNIQUE |
| password | VARCHAR(100) |
| nombre | VARCHAR(100) |
| rol | VARCHAR(30) |

## Estructura del código

```
dao/       → ProductoDAO, UsuarioDAO  (SQL con PreparedStatement)
util/      → DatabaseConnection       (SQL Server JDBC)
service/   → ProductoService
controller/→ Servlets + Login + AuthFilter
resources/db/ → scripts SQL para SSMS
resources/db.properties → conexión
```
