-- ============================================================
-- Datos iniciales - Microsoft SQL Server
-- ============================================================

-- Usuario de acceso
IF NOT EXISTS (SELECT 1 FROM dbo.usuarios WHERE username = 'Adrian')
BEGIN
    INSERT INTO dbo.usuarios (username, password, nombre, rol)
    VALUES ('Adrian', 'hololive2026', 'Adrian', 'ADMIN');
END
GO

-- Productos de ejemplo
IF NOT EXISTS (SELECT 1 FROM dbo.productos WHERE codigo = 'P001')
BEGIN
    INSERT INTO dbo.productos (codigo, nombre, categoria, precio, stock, estado) VALUES
    ('P001', 'Laptop Lenovo IdeaPad',       'Computadoras', 2500.00, 10, 'Disponible'),
    ('P002', 'Mouse Logitech M170',          'Accesorios',     80.00, 25, 'Disponible'),
    ('P003', 'Teclado Redragon Kumara',      'Accesorios',    150.00,  0, 'Agotado'),
    ('P004', 'Monitor Samsung 24"',          'Monitores',     760.00,  8, 'Disponible'),
    ('P005', 'Impresora Epson L3250',        'Impresoras',    920.00,  4, 'Disponible'),
    ('P006', 'Webcam Logitech C920',         'Accesorios',    340.00, 12, 'Disponible'),
    ('P007', 'Auriculares HyperX Cloud',     'Audio',         280.00, 15, 'Disponible'),
    ('P008', 'SSD Kingston 1TB',             'Accesorios',    320.00, 20, 'Disponible'),
    ('P009', 'Laptop HP Pavilion 15',        'Computadoras', 3100.00,  5, 'Disponible'),
    ('P010', 'Mouse Razer DeathAdder',       'Accesorios',    210.00,  0, 'Agotado'),
    ('P011', 'Monitor LG UltraWide 29"',     'Monitores',    1450.00,  3, 'Disponible'),
    ('P012', 'Teclado Mecanico Keychron K2', 'Accesorios',    480.00,  7, 'Disponible'),
    ('P013', 'Impresora HP DeskJet 2775',    'Impresoras',    450.00,  0, 'Agotado'),
    ('P014', 'Parlantes Logitech Z313',      'Audio',         190.00, 18, 'Disponible'),
    ('P015', 'Laptop ASUS VivoBook',         'Computadoras', 2750.00,  6, 'Disponible'),
    ('P016', 'Hub USB-C 7 en 1',             'Accesorios',     95.00, 30, 'Disponible'),
    ('P017', 'Monitor Dell 27"',             'Monitores',     980.00,  2, 'Disponible'),
    ('P018', 'Microfono Blue Yeti',          'Audio',         520.00,  0, 'Agotado'),
    ('P019', 'Laptop Acer Aspire 5',         'Computadoras', 2300.00,  9, 'Disponible'),
    ('P020', 'Mousepad XXL RGB',             'Accesorios',     65.00, 40, 'Disponible');
END
GO
