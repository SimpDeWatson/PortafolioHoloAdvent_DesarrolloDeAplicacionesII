-- ============================================================
-- EJECUTAR PRIMERO EN SQL SERVER MANAGEMENT STUDIO (SSMS)
-- Conéctate al servidor (localhost o .) con autenticación Windows
-- o SQL Server, y ejecuta este script completo.
-- ============================================================

IF DB_ID('AdventStock') IS NULL
BEGIN
    CREATE DATABASE AdventStock;
END
GO

USE AdventStock;
GO

-- Tablas
IF OBJECT_ID('dbo.productos', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.productos (
        codigo      VARCHAR(20)  NOT NULL PRIMARY KEY,
        nombre      VARCHAR(150) NOT NULL,
        categoria   VARCHAR(50)  NOT NULL,
        precio      DECIMAL(12,2) NOT NULL CHECK (precio > 0),
        stock       INT          NOT NULL CHECK (stock >= 0),
        estado      VARCHAR(30)  NOT NULL,
        imagen      VARBINARY(MAX) NULL,
        imagen_tipo VARCHAR(50)  NULL
    );
END
GO

IF OBJECT_ID('dbo.usuarios', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.usuarios (
        id          INT IDENTITY(1,1) PRIMARY KEY,
        username    VARCHAR(50)  NOT NULL UNIQUE,
        password    VARCHAR(100) NOT NULL,
        nombre      VARCHAR(100) NOT NULL,
        rol         VARCHAR(30)  NOT NULL DEFAULT 'ADMIN'
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'idx_productos_categoria' AND object_id = OBJECT_ID('dbo.productos'))
    CREATE INDEX idx_productos_categoria ON dbo.productos(categoria);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'idx_productos_estado' AND object_id = OBJECT_ID('dbo.productos'))
    CREATE INDEX idx_productos_estado ON dbo.productos(estado);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'idx_productos_nombre' AND object_id = OBJECT_ID('dbo.productos'))
    CREATE INDEX idx_productos_nombre ON dbo.productos(nombre);
GO

-- Usuario
IF NOT EXISTS (SELECT 1 FROM dbo.usuarios WHERE username = 'Adrian')
    INSERT INTO dbo.usuarios (username, password, nombre, rol)
    VALUES ('Adrian', 'hololive2026', 'Adrian', 'ADMIN');
GO

-- Productos
IF NOT EXISTS (SELECT 1 FROM dbo.productos WHERE codigo = 'P001')
BEGIN
    INSERT INTO dbo.productos (codigo, nombre, categoria, precio, stock, estado) VALUES
    ('P001', 'Laptop Lenovo IdeaPad',       'Computadoras', 2500.00, 10, 'Disponible'),
    ('P002', 'Mouse Logitech M170',          'Accesorios',     80.00, 25, 'Disponible'),
    ('P003', 'Teclado Redragon Kumara',      'Accesorios',    150.00,  0, 'Agotado'),
    ('P004', 'Monitor Samsung 24"',          'Monitores',     760.00,  8, 'Disponible'),
    ('P005', 'Impresora Epson L3250',        'Impresoras',    920.00,  4, 'Disponible'),
    ('P006', 'Webcam Logitech C920',         'Accesorios',    340.00, 12, 'Disponible'),
    ('P007', 'Auriculares HyperX Cloud',     'Audio',         280.00, 15, 'Disponible'),
    ('P008', 'SSD Kingston 1TB',             'Accesorios',    320.00, 20, 'Disponible'),
    ('P009', 'Laptop HP Pavilion 15',        'Computadoras', 3100.00,  5, 'Disponible'),
    ('P010', 'Mouse Razer DeathAdder',       'Accesorios',    210.00,  0, 'Agotado'),
    ('P011', 'Monitor LG UltraWide 29"',     'Monitores',    1450.00,  3, 'Disponible'),
    ('P012', 'Teclado Mecanico Keychron K2', 'Accesorios',    480.00,  7, 'Disponible'),
    ('P013', 'Impresora HP DeskJet 2775',    'Impresoras',    450.00,  0, 'Agotado'),
    ('P014', 'Parlantes Logitech Z313',      'Audio',         190.00, 18, 'Disponible'),
    ('P015', 'Laptop ASUS VivoBook',         'Computadoras', 2750.00,  6, 'Disponible'),
    ('P016', 'Hub USB-C 7 en 1',             'Accesorios',     95.00, 30, 'Disponible'),
    ('P017', 'Monitor Dell 27"',             'Monitores',     980.00,  2, 'Disponible'),
    ('P018', 'Microfono Blue Yeti',          'Audio',         520.00,  0, 'Agotado'),
    ('P019', 'Laptop Acer Aspire 5',         'Computadoras', 2300.00,  9, 'Disponible'),
    ('P020', 'Mousepad XXL RGB',             'Accesorios',     65.00, 40, 'Disponible');
END
GO

PRINT 'Base de datos AdventStock lista.';
GO
