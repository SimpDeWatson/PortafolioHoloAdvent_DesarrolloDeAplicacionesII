-- ============================================================
-- AdventStock - Esquema para Microsoft SQL Server
-- Ejecutar en SSMS sobre la base de datos AdventStock
-- ============================================================

IF OBJECT_ID('dbo.productos', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.productos (
        codigo      VARCHAR(20)  NOT NULL PRIMARY KEY,
        nombre      VARCHAR(150) NOT NULL,
        categoria   VARCHAR(50)  NOT NULL,
        precio      DECIMAL(12,2) NOT NULL CHECK (precio > 0),
        stock       INT          NOT NULL CHECK (stock >= 0),
        estado      VARCHAR(30)  NOT NULL,
        imagen      VARBINARY(MAX) NULL,
        imagen_tipo VARCHAR(50)  NULL
    );
END
GO

IF OBJECT_ID('dbo.usuarios', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.usuarios (
        id          INT IDENTITY(1,1) PRIMARY KEY,
        username    VARCHAR(50)  NOT NULL UNIQUE,
        password    VARCHAR(100) NOT NULL,
        nombre      VARCHAR(100) NOT NULL,
        rol         VARCHAR(30)  NOT NULL DEFAULT 'ADMIN'
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'idx_productos_categoria' AND object_id = OBJECT_ID('dbo.productos'))
    CREATE INDEX idx_productos_categoria ON dbo.productos(categoria);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'idx_productos_estado' AND object_id = OBJECT_ID('dbo.productos'))
    CREATE INDEX idx_productos_estado ON dbo.productos(estado);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'idx_productos_nombre' AND object_id = OBJECT_ID('dbo.productos'))
    CREATE INDEX idx_productos_nombre ON dbo.productos(nombre);
GO
