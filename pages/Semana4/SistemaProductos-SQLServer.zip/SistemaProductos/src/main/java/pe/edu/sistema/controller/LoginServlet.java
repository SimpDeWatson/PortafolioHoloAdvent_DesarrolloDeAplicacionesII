package pe.edu.sistema.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import pe.edu.sistema.dao.UsuarioDAO;

import java.io.IOException;

/**
 * Controlador de inicio de sesión.
 * Valida contra la tabla USUARIOS de la base de datos.
 * Credenciales por defecto: Adrian / hololive2026
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    private final UsuarioDAO usuarioDAO = new UsuarioDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session != null && session.getAttribute("usuarioLogueado") != null) {
            response.sendRedirect(request.getContextPath() + "/index.jsp");
            return;
        }
        request.getRequestDispatcher("/login.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String usuario = request.getParameter("usuario");
        String clave = request.getParameter("clave");

        String nombre = usuarioDAO.autenticar(usuario, clave);
        if (nombre != null) {
            HttpSession session = request.getSession(true);
            session.setAttribute("usuarioLogueado", nombre);
            getServletContext().setAttribute("usuarioConectado", nombre);
            response.sendRedirect(request.getContextPath() + "/index.jsp");
        } else {
            request.setAttribute("error", "Usuario o contraseña incorrectos. Intenta de nuevo.");
            request.getRequestDispatcher("/login.jsp").forward(request, response);
        }
    }
}
