package pe.edu.sistema.dao;

import pe.edu.sistema.util.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Acceso a datos de la tabla usuarios (login).
 */
public class UsuarioDAO {

    /**
     * Valida credenciales. Devuelve el nombre del usuario si es correcto, null si no.
     */
    public String autenticar(String username, String password) {
        String sql = "SELECT nombre FROM usuarios WHERE username = ? AND password = ?";
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, password);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("nombre");
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error al autenticar usuario", e);
        }
        return null;
    }
}
