package pe.edu.sistema.util;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Conexión a Microsoft SQL Server.
 * Lee la configuración desde /db.properties (en resources).
 *
 * Antes de ejecutar la app:
 * 1. Crea la BD con el script resources/db/00_crear_base_datos.sql en SSMS
 * 2. Ajusta server, user y password en db.properties
 */
public final class DatabaseConnection {

    private static final Properties PROPS = new Properties();
    private static String url;
    private static String user;
    private static String password;
    private static boolean loaded = false;

    private DatabaseConnection() {}

    private static synchronized void load() {
        if (loaded) return;
        try (InputStream in = DatabaseConnection.class.getResourceAsStream("/db.properties")) {
            if (in == null) {
                throw new RuntimeException("No se encontró db.properties en resources");
            }
            PROPS.load(in);
        } catch (Exception e) {
            throw new RuntimeException("Error leyendo db.properties: " + e.getMessage(), e);
        }

        String server = PROPS.getProperty("db.server", "localhost");
        String port = PROPS.getProperty("db.port", "1433");
        String name = PROPS.getProperty("db.name", "AdventStock");
        boolean integrated = Boolean.parseBoolean(PROPS.getProperty("db.integratedSecurity", "false"));

        user = PROPS.getProperty("db.user", "sa");
        password = PROPS.getProperty("db.password", "");

        StringBuilder sb = new StringBuilder();
        sb.append("jdbc:sqlserver://").append(server);
        if (port != null && !port.isBlank()) {
            sb.append(":").append(port);
        }
        sb.append(";databaseName=").append(name);
        sb.append(";encrypt=true;trustServerCertificate=true");
        if (integrated) {
            sb.append(";integratedSecurity=true");
        }
        url = sb.toString();
        loaded = true;
        System.out.println("[AdventStock] SQL Server URL: " + url.replace(password, "***"));
    }

    public static Connection getConnection() throws SQLException {
        load();
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        } catch (ClassNotFoundException e) {
            throw new SQLException("Driver SQL Server no encontrado. Revisa el pom.xml (mssql-jdbc)", e);
        }
        if (Boolean.parseBoolean(PROPS.getProperty("db.integratedSecurity", "false"))) {
            return DriverManager.getConnection(url);
        }
        return DriverManager.getConnection(url, user, password);
    }
}
