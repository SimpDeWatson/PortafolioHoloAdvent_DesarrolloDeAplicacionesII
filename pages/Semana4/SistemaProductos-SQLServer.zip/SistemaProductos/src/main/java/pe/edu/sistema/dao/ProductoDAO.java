package pe.edu.sistema.dao;

import pe.edu.sistema.model.Producto;
import pe.edu.sistema.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Acceso a datos (DAO) de la tabla productos.
 */
public class ProductoDAO {

    public List<Producto> listarTodos() {
        List<Producto> lista = new ArrayList<>();
        String sql = "SELECT codigo, nombre, categoria, precio, stock, estado, imagen, imagen_tipo FROM productos ORDER BY codigo";
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(map(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error al listar productos", e);
        }
        return lista;
    }

    public Producto buscarPorCodigo(String codigo) {
        String sql = "SELECT codigo, nombre, categoria, precio, stock, estado, imagen, imagen_tipo FROM productos WHERE UPPER(codigo)=UPPER(?)";
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, codigo);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return map(rs);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error al buscar producto", e);
        }
        return null;
    }

    public boolean existeCodigo(String codigo) {
        return buscarPorCodigo(codigo) != null;
    }

    public List<Producto> buscar(String codigo, String nombre, String categoria) {
        StringBuilder sb = new StringBuilder(
                "SELECT codigo, nombre, categoria, precio, stock, estado, imagen, imagen_tipo FROM productos WHERE 1=1");
        List<Object> params = new ArrayList<>();

        if (codigo != null && !codigo.isBlank()) {
            sb.append(" AND UPPER(codigo) LIKE UPPER(?)");
            params.add("%" + codigo.trim() + "%");
        }
        if (nombre != null && !nombre.isBlank()) {
            sb.append(" AND UPPER(nombre) LIKE UPPER(?)");
            params.add("%" + nombre.trim() + "%");
        }
        if (categoria != null && !categoria.isBlank()
                && !"Todas las categorías".equalsIgnoreCase(categoria)
                && !"Todas".equalsIgnoreCase(categoria)) {
            sb.append(" AND UPPER(categoria)=UPPER(?)");
            params.add(categoria.trim());
        }
        sb.append(" ORDER BY codigo");

        List<Producto> lista = new ArrayList<>();
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sb.toString())) {
            for (int i = 0; i < params.size(); i++) {
                ps.setObject(i + 1, params.get(i));
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) lista.add(map(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error al buscar productos", e);
        }
        return lista;
    }

    public List<Producto> listarDisponibles() {
        String sql = "SELECT codigo, nombre, categoria, precio, stock, estado, imagen, imagen_tipo "
                   + "FROM productos WHERE stock > 0 AND UPPER(estado)='DISPONIBLE' ORDER BY codigo";
        List<Producto> lista = new ArrayList<>();
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) lista.add(map(rs));
        } catch (SQLException e) {
            throw new RuntimeException("Error al listar disponibles", e);
        }
        return lista;
    }

    public boolean insertar(Producto p) {
        String sql = "INSERT INTO productos (codigo, nombre, categoria, precio, stock, estado, imagen, imagen_tipo) "
                   + "VALUES (?,?,?,?,?,?,?,?)";
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            setParams(ps, p);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            // SQL Server: 2627 = unique constraint, 2601 = duplicate key index
            // H2 legacy: 23505
            int code = e.getErrorCode();
            if (code == 2627 || code == 2601 || code == 23505
                    || (e.getMessage() != null && e.getMessage().toLowerCase().contains("unique"))) {
                return false; // código duplicado
            }
            throw new RuntimeException("Error al insertar producto", e);
        }
    }

    public boolean actualizar(Producto p) {
        String sql = "UPDATE productos SET nombre=?, categoria=?, precio=?, stock=?, estado=?, imagen=?, imagen_tipo=? "
                   + "WHERE UPPER(codigo)=UPPER(?)";
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, p.getNombre());
            ps.setString(2, p.getCategoria());
            ps.setDouble(3, p.getPrecio());
            ps.setInt(4, p.getStock());
            ps.setString(5, p.getEstado());
            if (p.getImagen() != null) {
                ps.setBytes(6, p.getImagen());
                ps.setString(7, p.getImagenTipo());
            } else {
                ps.setNull(6, Types.BLOB);
                ps.setNull(7, Types.VARCHAR);
            }
            ps.setString(8, p.getCodigo());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new RuntimeException("Error al actualizar producto", e);
        }
    }

    public boolean eliminar(String codigo) {
        String sql = "DELETE FROM productos WHERE UPPER(codigo)=UPPER(?)";
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, codigo);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new RuntimeException("Error al eliminar producto", e);
        }
    }

    public int contarTotal() {
        return count("SELECT COUNT(*) FROM productos");
    }

    public int contarDisponibles() {
        return count("SELECT COUNT(*) FROM productos WHERE stock > 0");
    }

    public int contarAgotados() {
        return count("SELECT COUNT(*) FROM productos WHERE stock <= 0");
    }

    public double valorTotalInventario() {
        String sql = "SELECT COALESCE(SUM(precio * stock), 0) FROM productos";
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getDouble(1);
        } catch (SQLException e) {
            throw new RuntimeException("Error al calcular valor inventario", e);
        }
        return 0;
    }

    public int stockTotal() {
        return count("SELECT COALESCE(SUM(stock), 0) FROM productos");
    }

    private int count(String sql) {
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            throw new RuntimeException("Error en conteo", e);
        }
        return 0;
    }

    private void setParams(PreparedStatement ps, Producto p) throws SQLException {
        ps.setString(1, p.getCodigo());
        ps.setString(2, p.getNombre());
        ps.setString(3, p.getCategoria());
        ps.setDouble(4, p.getPrecio());
        ps.setInt(5, p.getStock());
        ps.setString(6, p.getEstado());
        if (p.getImagen() != null) {
            ps.setBytes(7, p.getImagen());
            ps.setString(8, p.getImagenTipo());
        } else {
            ps.setNull(7, Types.BLOB);
            ps.setNull(8, Types.VARCHAR);
        }
    }

    private Producto map(ResultSet rs) throws SQLException {
        Producto p = new Producto();
        p.setCodigo(rs.getString("codigo"));
        p.setNombre(rs.getString("nombre"));
        p.setCategoria(rs.getString("categoria"));
        p.setPrecio(rs.getDouble("precio"));
        p.setStock(rs.getInt("stock"));
        p.setEstado(rs.getString("estado"));
        byte[] img = rs.getBytes("imagen");
        if (img != null && img.length > 0) {
            p.setImagen(img);
            p.setImagenTipo(rs.getString("imagen_tipo"));
        }
        return p;
    }
}
