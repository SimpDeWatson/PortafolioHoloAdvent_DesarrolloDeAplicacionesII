package pe.edu.sistema.controller;

import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;
import pe.edu.sistema.service.ProductoService;
import pe.edu.sistema.util.DatabaseConnection;

/**
 * Inicializa datos globales y verifica la conexión a SQL Server al arrancar.
 * Las tablas deben crearse antes con el script 00_crear_base_datos.sql en SSMS.
 */
@WebListener
public class AppContextListener implements ServletContextListener {

    public static final String NOMBRE_SISTEMA = "Sistema Web de Gestión de Productos";
    public static final String NOMBRE_CORTO = "AdventStock";
    public static final String DESCRIPCION_SISTEMA =
            "Registro, consulta, actualización y control del inventario. Arquitectura MVC + Microsoft SQL Server.";
    public static final String USUARIO_CONECTADO = "Invitado";

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        sce.getServletContext().setAttribute("nombreSistema", NOMBRE_SISTEMA);
        sce.getServletContext().setAttribute("nombreCorto", NOMBRE_CORTO);
        sce.getServletContext().setAttribute("descripcionSistema", DESCRIPCION_SISTEMA);
        sce.getServletContext().setAttribute("usuarioConectado", USUARIO_CONECTADO);

        try {
            DatabaseConnection.getConnection().close();
            ProductoService.getInstancia(); // carga imágenes sobre productos existentes
            System.out.println("[AdventStock] Conectado a SQL Server correctamente.");
        } catch (Exception e) {
            System.err.println("[AdventStock] ERROR de conexión a SQL Server: " + e.getMessage());
            System.err.println("[AdventStock] 1) Ejecuta resources/db/00_crear_base_datos.sql en SSMS");
            System.err.println("[AdventStock] 2) Revisa db.properties (server, user, password)");
            e.printStackTrace();
        }
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
    }
}
