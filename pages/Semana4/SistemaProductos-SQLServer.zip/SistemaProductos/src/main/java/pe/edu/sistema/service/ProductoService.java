package pe.edu.sistema.service;

import pe.edu.sistema.dao.ProductoDAO;
import pe.edu.sistema.model.Producto;

import java.io.InputStream;
import java.util.List;

/**
 * Capa de servicio (lógica de negocio).
 * Ahora usa base de datos H2 a través de ProductoDAO (ya no ArrayList en memoria).
 */
public class ProductoService {

    private static final ProductoService INSTANCIA = new ProductoService();
    private final ProductoDAO dao = new ProductoDAO();

    public static final String[] CATEGORIAS = {
            "Computadoras", "Accesorios", "Impresoras", "Monitores", "Audio", "Otros"
    };

    public static final String[] ESTADOS = {
            "Disponible", "Agotado", "Descontinuado"
    };

    private ProductoService() {
        // La BD se inicializa al primer getConnection() (schema + data)
        // Cargar imágenes de resources/imagenes sobre los productos de ejemplo
        cargarImagenesDesdeResources();
    }

    public static ProductoService getInstancia() {
        return INSTANCIA;
    }

    private void cargarImagenesDesdeResources() {
        try {
            for (int i = 1; i <= 20; i++) {
                String codigo = String.format("P%03d", i);
                String base = String.format("p%03d", i);
                Producto p = dao.buscarPorCodigo(codigo);
                if (p == null || p.isTieneImagen()) continue;

                String[][] formatos = {
                    {"jpg", "image/jpeg"}, {"jpeg", "image/jpeg"},
                    {"png", "image/png"}, {"webp", "image/webp"}
                };
                for (String[] f : formatos) {
                    try (InputStream in = ProductoService.class
                            .getResourceAsStream("/imagenes/" + base + "." + f[0])) {
                        if (in != null) {
                            p.setImagen(in.readAllBytes());
                            p.setImagenTipo(f[1]);
                            dao.actualizar(p);
                            break;
                        }
                    } catch (Exception ignored) {}
                }
            }
        } catch (Exception e) {
            System.err.println("[AdventStock] No se pudieron cargar imágenes: " + e.getMessage());
        }
    }

    // ---------- API usada por los Servlets ----------

    public List<Producto> listarTodos() {
        return dao.listarTodos();
    }

    public Producto buscarPorCodigo(String codigo) {
        return dao.buscarPorCodigo(codigo);
    }

    public boolean existeCodigo(String codigo) {
        return dao.existeCodigo(codigo);
    }

    public List<Producto> buscar(String codigo, String nombre, String categoria) {
        return dao.buscar(codigo, nombre, categoria);
    }

    public List<Producto> listarDisponibles() {
        return dao.listarDisponibles();
    }

    public synchronized boolean registrar(Producto nuevo) {
        return dao.insertar(nuevo);
    }

    public synchronized void agregar(Producto producto) {
        dao.insertar(producto);
    }

    public synchronized boolean actualizar(Producto actualizado) {
        return dao.actualizar(actualizado);
    }

    public synchronized boolean eliminar(String codigo) {
        return dao.eliminar(codigo);
    }

    public int totalProductos() { return dao.contarTotal(); }
    public int totalDisponibles() { return dao.contarDisponibles(); }
    public int totalAgotados() { return dao.contarAgotados(); }
    public double valorTotalInventario() { return dao.valorTotalInventario(); }
    public int stockTotal() { return dao.stockTotal(); }

    // Alias de compatibilidad con JSP / Servlets existentes
    public int contarTotalProductos() { return totalProductos(); }
    public int contarDisponibles() { return totalDisponibles(); }
    public int contarAgotados() { return totalAgotados(); }
    public double calcularValorTotalInventario() { return valorTotalInventario(); }
    public int calcularStockTotal() { return stockTotal(); }
}
