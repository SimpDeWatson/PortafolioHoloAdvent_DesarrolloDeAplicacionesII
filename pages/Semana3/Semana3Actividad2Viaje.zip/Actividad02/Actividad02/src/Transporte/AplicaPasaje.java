package Transporte;

import java.util.Locale;
import java.util.Scanner;

/**
 * Actividad 02
 * Sistema de venta de pasajes: permite atender a varios clientes en una
 * misma ejecución, informando a cada uno las condiciones de descuento y
 * obsequio antes de procesar su compra.
 */
public class AplicaPasaje {

    static Scanner teclado = new Scanner(System.in);

    public static void main(String[] args) {
        teclado.useLocale(Locale.US);
        mostrarBienvenida();

        char respuesta;
        int numeroCliente = 1;

        do {
            System.out.println("\n==========================================");
            System.out.println("            ATENDIENDO AL CLIENTE N° " + numeroCliente);
            System.out.println("================================================");

            String turno;
            do {
                System.out.print("Ingrese el turno (Mañana/Noche): ");
                turno = teclado.next();
            } while (turno.isEmpty());

            int cantidadPasajes;
            do {
                System.out.print("Ingrese la cantidad de pasajes que desea comprar: ");
                cantidadPasajes = teclado.nextInt();
            } while (cantidadPasajes <= 0);

            // Se crea el objeto Pasaje con los datos del cliente actual
            Pasaje pasaje = new Pasaje(turno, cantidadPasajes);
            pasaje.procesarCompra();
            pasaje.mostrarResultado();

            numeroCliente++;

            System.out.print("\n¿Desea atender a otro cliente? (S = Sí / N = No): ");
            respuesta = teclado.next().toUpperCase().charAt(0);

        } while (respuesta == 'S');

        System.out.println("\nSe atendieron " + (numeroCliente - 1) + " cliente(s). ¡Hasta pronto!");
    }

    static void mostrarBienvenida() {
        System.out.println("=================================================");
        System.out.println("   BIENVENIDO AL SISTEMA DE VENTA DE PASAJES");
        System.out.println("          Ruta: Lima - Huancayo");
        System.out.println("=================================================");
        System.out.println("Condiciones de la promoción vigente:");
        System.out.println("  - Descuento: 8% si compra 15 pasajes o más.");
        System.out.println("               5% si compra menos de 15 pasajes.");
        System.out.println("  - Obsequio : 2 caramelos por cada boleto, si el");
        System.out.println("               importe a pagar supera los S/. 200.");
        System.out.println("=================================================");
    }
}
