package Transporte;

import java.util.Locale;

/**
 * Actividad 02
 * Representa la compra de pasajes de la ruta Lima - Huancayo, con descuento
 * escalonado según la cantidad de pasajes y obsequio de caramelos según el
 * importe a pagar.
 */
public class Pasaje {

    // ================== ATRIBUTOS ==================
    private String turno;              // "Mañana" o "Noche"
    private int cantidadPasajes;
    private static final double PRECIO_PASAJE = 37.5; // S/. 37.5 en ambos turnos

    private double importeCompra;
    private double porcentajeDescuento;
    private double importeDescuento;
    private double importeAPagar;
    private int cantidadCaramelos;

    // ================== CONSTRUCTOR ==================
    public Pasaje(String turno, int cantidadPasajes) {
        this.turno = turno;
        this.cantidadPasajes = cantidadPasajes;
    }

    // ================== GETTERS Y SETTERS ==================
    public String getTurno() { return turno; }
    public void setTurno(String turno) { this.turno = turno; }

    public int getCantidadPasajes() { return cantidadPasajes; }
    public void setCantidadPasajes(int cantidadPasajes) { this.cantidadPasajes = cantidadPasajes; }

    public double getPrecioPasaje() { return PRECIO_PASAJE; }
    public double getImporteCompra() { return importeCompra; }
    public double getPorcentajeDescuento() { return porcentajeDescuento; }
    public double getImporteDescuento() { return importeDescuento; }
    public double getImporteAPagar() { return importeAPagar; }
    public int getCantidadCaramelos() { return cantidadCaramelos; }

    // ================== MÉTODOS DE CÁLCULO ==================

    // Importe de la compra = precio del pasaje x cantidad de pasajes
    public double calcularImporteCompra() {
        importeCompra = PRECIO_PASAJE * cantidadPasajes;
        return importeCompra;
    }

    // Pasajes >= 15 -> 8% ; Pasajes < 15 -> 5%
    public double calcularPorcentajeDescuento() {
        porcentajeDescuento = (cantidadPasajes >= 15) ? 0.08 : 0.05;
        return porcentajeDescuento;
    }

    public double calcularImporteDescuento() {
        importeDescuento = importeCompra * porcentajeDescuento;
        return importeDescuento;
    }

    public double calcularImporteAPagar() {
        importeAPagar = importeCompra - importeDescuento;
        return importeAPagar;
    }

    // Importe a pagar > 200 -> 2 caramelos por cada boleto ; si no, 0
    public int calcularCantidadCaramelos() {
        cantidadCaramelos = (importeAPagar > 200) ? 2 * cantidadPasajes : 0;
        return cantidadCaramelos;
    }

    // Ejecuta todos los cálculos en el orden correcto
    public void procesarCompra() {
        calcularImporteCompra();
        calcularPorcentajeDescuento();
        calcularImporteDescuento();
        calcularImporteAPagar();
        calcularCantidadCaramelos();
    }

    // ================== MÉTODO DE VISUALIZACIÓN (BOLETO AL CLIENTE) ==================
    public void mostrarResultado() {
        System.out.println("\n=================================================");
        System.out.println("\t     BOLETO DE VIAJE");
        System.out.println("\t   Ruta: Lima - Huancayo");
        System.out.println("=================================================");
        System.out.println("Turno                  : " + turno);
        System.out.println(String.format(Locale.US, "Precio del pasaje      : S/. %.2f", PRECIO_PASAJE));
        System.out.println(String.format(Locale.US, "Pasajes comprados      : %d", cantidadPasajes));
        System.out.println("-------------------------------------------------");
        System.out.println(String.format(Locale.US, "Importe de la compra   : S/. %.2f", importeCompra));

        // ---- Explicación del descuento obtenido ----
        if (cantidadPasajes >= 15) {
            System.out.println("¡Felicidades! Por comprar 15 o más pasajes,");
            System.out.println("accede a un DESCUENTO DEL 8%.");
        } else {
            System.out.println("Por comprar menos de 15 pasajes,");
            System.out.println("accede a un descuento del 5%.");
            System.out.println("Tip: compre 15 pasajes o más y su descuento sube a 8%.");
        }
        System.out.println(String.format(Locale.US, "Descuento aplicado     : %.0f%%  (S/. %.2f)",
                porcentajeDescuento * 100, importeDescuento));
        System.out.println("-------------------------------------------------");
        System.out.println(String.format(Locale.US, "IMPORTE A PAGAR        : S/. %.2f", importeAPagar));
        System.out.println("-------------------------------------------------");

        // ---- Explicación del obsequio ----
        if (cantidadCaramelos > 0) {
            System.out.println("¡Su compra califica para el OBSEQUIO!");
            System.out.println("Por pagar más de S/. 200.00, recibe 2 caramelos");
            System.out.println("por cada boleto comprado.");
            System.out.println("CARAMELOS DE REGALO    : " + cantidadCaramelos);
        } else {
            System.out.println("Su compra no superó los S/. 200.00 a pagar,");
            System.out.println("por lo que esta vez no accede al obsequio de caramelos.");
            System.out.println("CARAMELOS DE REGALO    : 0");
        }
        System.out.println("=================================================");
        System.out.println("       Buen viaje, gracias por su preferencia");
        System.out.println("=================================================");
    }
}
