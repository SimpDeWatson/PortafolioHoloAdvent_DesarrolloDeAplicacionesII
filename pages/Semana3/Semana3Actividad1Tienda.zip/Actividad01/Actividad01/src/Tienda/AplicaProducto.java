package Tienda;

import java.util.Locale;
import java.util.Scanner;

/**
 * Actividad 01
 * Sistema de atención en tienda: permite registrar la compra de varios
 * clientes en una misma ejecución, informando a cada uno las condiciones
 * de descuento y obsequio antes de procesar su compra.
 */
public class AplicaProducto {

    static Scanner teclado = new Scanner(System.in);

    public static void main(String[] args) {
        teclado.useLocale(Locale.US);
        mostrarBienvenida();

        char respuesta;
        int numeroCliente = 1;

        do {
            System.out.println("\n==============================================");
            System.out.println("            ATENDIENDO AL CLIENTE N° " + numeroCliente);
            System.out.println("===================================================");

            double precioDocena;
            do {
                System.out.print("Ingrese el precio de la docena (S/.): ");
                precioDocena = teclado.nextDouble();
            } while (precioDocena <= 0);

            int cantidadDocenas;
            do {
                System.out.print("Ingrese la cantidad de docenas que desea comprar: ");
                cantidadDocenas = teclado.nextInt();
            } while (cantidadDocenas <= 0);

            // Se crea el objeto Producto con los datos del cliente actual
            Producto producto = new Producto(precioDocena, cantidadDocenas);
            producto.procesarCompra();
            producto.mostrarResultado();

            numeroCliente++;

            System.out.print("\n¿Desea atender a otro cliente? (S = Sí / N = No): ");
            respuesta = teclado.next().toUpperCase().charAt(0);
            teclado.nextLine(); // limpiar el salto de línea pendiente antes del siguiente cliente

        } while (respuesta == 'S');

        System.out.println("\nSe atendieron " + (numeroCliente - 1) + " cliente(s). ¡Hasta pronto!");
    }

    static void mostrarBienvenida() {
        System.out.println("=================================================");
        System.out.println("     BIENVENIDO AL SISTEMA DE VENTAS DE LA TIENDA");
        System.out.println("               Producto: Cuaderno");
        System.out.println("=================================================");
        System.out.println("Condiciones de la promoción vigente:");
        System.out.println("  - Descuento: 20% si compra 10 docenas o más.");
        System.out.println("               10% si compra menos de 10 docenas.");
        System.out.println("  - Obsequio : 2 lapiceros por cada docena, si el");
        System.out.println("               importe a pagar es S/. 200 o más.");
        System.out.println("=================================================");
    }
}
