package Tienda;

import java.util.Locale;

/**
 * Actividad 01
 * Representa la compra de un producto vendido por docenas, con descuento
 * escalonado y obsequio de lapiceros según el importe a pagar.
 */
public class Producto {

    // ================== ATRIBUTOS ==================
    private static final String NOMBRE_PRODUCTO = "Cuaderno"; // producto fijo de la tienda
    private double precioDocena;
    private int cantidadDocenas;

    private double importeCompra;
    private double porcentajeDescuento;
    private double importeDescuento;
    private double importeAPagar;
    private int cantidadLapiceros;

    // ================== CONSTRUCTOR ==================
    public Producto(double precioDocena, int cantidadDocenas) {
        this.precioDocena = precioDocena;
        this.cantidadDocenas = cantidadDocenas;
    }

    // ================== GETTERS Y SETTERS ==================
    public String getNombreProducto() { return NOMBRE_PRODUCTO; }

    public double getPrecioDocena() { return precioDocena; }
    public void setPrecioDocena(double precioDocena) { this.precioDocena = precioDocena; }

    public int getCantidadDocenas() { return cantidadDocenas; }
    public void setCantidadDocenas(int cantidadDocenas) { this.cantidadDocenas = cantidadDocenas; }

    public double getImporteCompra() { return importeCompra; }
    public double getPorcentajeDescuento() { return porcentajeDescuento; }
    public double getImporteDescuento() { return importeDescuento; }
    public double getImporteAPagar() { return importeAPagar; }
    public int getCantidadLapiceros() { return cantidadLapiceros; }

    // ================== MÉTODOS DE CÁLCULO ==================

    // Importe de la compra = precio de la docena x cantidad de docenas
    public double calcularImporteCompra() {
        importeCompra = precioDocena * cantidadDocenas;
        return importeCompra;
    }

    // Docenas >= 10 -> 20% ; Docenas < 10 -> 10%
    public double calcularPorcentajeDescuento() {
        porcentajeDescuento = (cantidadDocenas >= 10) ? 0.20 : 0.10;
        return porcentajeDescuento;
    }

    public double calcularImporteDescuento() {
        importeDescuento = importeCompra * porcentajeDescuento;
        return importeDescuento;
    }

    public double calcularImporteAPagar() {
        importeAPagar = importeCompra - importeDescuento;
        return importeAPagar;
    }

    // Importe a pagar >= 200 -> 2 lapiceros por cada docena ; si no, 0
    public int calcularCantidadLapiceros() {
        cantidadLapiceros = (importeAPagar >= 200) ? 2 * cantidadDocenas : 0;
        return cantidadLapiceros;
    }

    // Ejecuta todos los cálculos en el orden correcto
    public void procesarCompra() {
        calcularImporteCompra();
        calcularPorcentajeDescuento();
        calcularImporteDescuento();
        calcularImporteAPagar();
        calcularCantidadLapiceros();
    }

    // ================== MÉTODO DE VISUALIZACIÓN (RECIBO AL CLIENTE) ==================
    public void mostrarResultado() {
        System.out.println("\n=================================================");
        System.out.println("\t   RECIBO DE COMPRA");
        System.out.println("=================================================");
        System.out.println("Producto               : " + NOMBRE_PRODUCTO);
        System.out.println(String.format(Locale.US, "Precio por docena      : S/. %.2f", precioDocena));
        System.out.println(String.format(Locale.US, "Docenas compradas      : %d", cantidadDocenas));
        System.out.println("-------------------------------------------------");
        System.out.println(String.format(Locale.US, "Importe de la compra   : S/. %.2f", importeCompra));

        // ---- Explicación del descuento obtenido ----
        if (cantidadDocenas >= 10) {
            System.out.println("¡Felicidades! Por comprar 10 o más docenas,");
            System.out.println("accede a un DESCUENTO DEL 20%.");
        } else {
            System.out.println("Por comprar menos de 10 docenas,");
            System.out.println("accede a un descuento del 10%.");
            System.out.println("Tip: compre 10 docenas o más y su descuento sube a 20%.");
        }
        System.out.println(String.format(Locale.US, "Descuento aplicado     : %.0f%%  (S/. %.2f)",
                porcentajeDescuento * 100, importeDescuento));
        System.out.println("-------------------------------------------------");
        System.out.println(String.format(Locale.US, "IMPORTE A PAGAR        : S/. %.2f", importeAPagar));
        System.out.println("-------------------------------------------------");

        // ---- Explicación del obsequio ----
        if (cantidadLapiceros > 0) {
            System.out.println("¡Su compra califica para el OBSEQUIO!");
            System.out.println("Por pagar S/. 200.00 o más, recibe 2 lapiceros");
            System.out.println("por cada docena comprada.");
            System.out.println("LAPICEROS DE REGALO    : " + cantidadLapiceros);
        } else {
            System.out.println("Su compra no alcanzó los S/. 200.00 a pagar,");
            System.out.println("por lo que esta vez no accede al obsequio de lapiceros.");
            System.out.println("LAPICEROS DE REGALO    : 0");
        }
        System.out.println("=================================================");
        System.out.println("       ¡Gracias por su compra!");
        System.out.println("=================================================");
    }
}
